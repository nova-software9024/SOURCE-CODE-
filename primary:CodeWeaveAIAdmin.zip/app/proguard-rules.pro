# Add project specific ProGuard rules here.
# Keep Firebase models
-keep class com.google.firebase.** { *; }
