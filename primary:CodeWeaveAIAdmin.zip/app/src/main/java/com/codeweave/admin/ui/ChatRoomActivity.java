package com.codeweave.admin.ui;

import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.codeweave.admin.AdminChatNotifier;
import com.codeweave.admin.R;
import com.codeweave.admin.core.PushSender;
import com.codeweave.admin.util.ClickAnimationUtil;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ServerValue;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ChatRoomActivity extends AppCompatActivity {

    public static final String EXTRA_UID = "uid";

    private static final String CHAT_PATH = "chats";
    private static final String PREFS_ADMIN = "admin_prefs";
    private static final String KEY_FCM_SERVICE_ACCOUNT = "fcm_service_account";

    private String uid;
    private String userName = "User";

    private final List<ChatMessage> messages = new ArrayList<>();
    private MessageAdapter adapter;
    private RecyclerView messageList;
    private TextView emptyView;
    private EditText chatInput;

    private DatabaseReference msgRef;
    private DatabaseReference infoRef;
    private DatabaseReference userRef;
    private ChildEventListener msgListener;

    private ValueEventListener userNameListener;

    private static class ChatMessage {
        String sender; // "user" | "admin"
        String text;
        long ts;

        ChatMessage(String sender, String text, long ts) {
            this.sender = sender;
            this.text = text;
            this.ts = ts;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat_room);

        uid = getIntent().getStringExtra(EXTRA_UID);
        if (uid == null || uid.isEmpty()) {
            finish();
            return;
        }

        TextView back = findViewById(R.id.backBtn);
        back.setOnClickListener(v -> finish());
        ClickAnimationUtil.apply(back);
        TextView title = findViewById(R.id.pageTitle);
        title.setText(R.string.chat_title);

        messageList = findViewById(R.id.messageList);
        emptyView = findViewById(R.id.emptyView);
        chatInput = findViewById(R.id.chatInput);
        ImageButton sendButton = findViewById(R.id.sendButton);

        messageList.setLayoutManager(new LinearLayoutManager(this));
        adapter = new MessageAdapter();
        messageList.setAdapter(adapter);

        sendButton.setOnClickListener(v -> sendMessage());
        ClickAnimationUtil.apply(sendButton);
        chatInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                sendMessage();
                return true;
            }
            return false;
        });

        loadUserName();
        startListening();
    }

    private void loadUserName() {
        userRef = FirebaseDatabase.getInstance().getReference("users").child(uid);
        userNameListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snap) {
                String n = snap.child("name").getValue(String.class);
                if (n != null && !n.trim().isEmpty()) userName = n;
                TextView title = findViewById(R.id.pageTitle);
                if (title != null) title.setText(userName);
            }

            @Override
            public void onCancelled(DatabaseError error) {
            }
        };
        userRef.child("name").addListenerForSingleValueEvent(userNameListener);
    }

    private void startListening() {
        DatabaseReference chatRef = FirebaseDatabase.getInstance().getReference(CHAT_PATH).child(uid);
        msgRef = chatRef.child("messages");
        infoRef = chatRef.child("info");

        msgListener = new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot snap, String prev) {
                String text = str(snap.child("text"));
                String sender = str(snap.child("sender"));
                long ts = snap.child("ts").getValue(Long.class) != null
                        ? snap.child("ts").getValue(Long.class) : 0L;
                if (text.isEmpty()) return;
                messages.add(new ChatMessage(sender, text, ts));
                adapter.notifyItemInserted(messages.size() - 1);
                scrollToBottom();
                updateEmpty();
            }

            @Override
            public void onChildChanged(DataSnapshot s, String p) {}
            @Override
            public void onChildRemoved(DataSnapshot s) {}
            @Override
            public void onChildMoved(DataSnapshot s, String p) {}
            @Override
            public void onCancelled(DatabaseError error) {}
        };
        msgRef.addChildEventListener(msgListener);

        // Mark admin has seen the conversation.
        infoRef.child("adminRead").setValue(ServerValue.increment(1));
        // Clear the admin unread flag so the background watcher stops notifying for this room.
        infoRef.child("adminUnread").setValue(false);
        // Note: admin opening the chat should also clear pending notifications.
        AdminChatNotifier.markChatOpened(this, uid);
    }

    private void sendMessage() {
        String text = chatInput.getText().toString().trim();
        if (text.isEmpty()) return;
        if (msgRef == null) return;

        Map<String, Object> message = new HashMap<>();
        message.put("sender", "admin");
        message.put("text", text);
        message.put("ts", ServerValue.TIMESTAMP);

        msgRef.push().setValue(message);
        chatInput.setText("");

        Map<String, Object> info = new HashMap<>();
        info.put("lastMessage", text);
        info.put("lastTs", ServerValue.TIMESTAMP);
        info.put("lastSender", "admin");
        info.put("userUnread", true);
        info.put("userName", userName);
        infoRef.updateChildren(info);

        sendPushToUser(text);
    }

    private void sendPushToUser(String replyText) {
        try {
            final String serviceJson = getStoredServiceAccountJson();
            if (serviceJson.isEmpty()) return;
            userRef.child("fcmToken").addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot snap) {
                    String token = snap.getValue(String.class);
                    if (token == null || token.isEmpty()) return;
                    try {
                        final String title = getString(R.string.chat_title) + " · " + userName;
                        PushSender.ServiceAccount sa = PushSender.parseServiceAccount(serviceJson);
                        PushSender.sendToToken(sa, token, title, replyText, null);
                    } catch (Exception ignored) {
                    }
                }

                @Override
                public void onCancelled(DatabaseError error) {
                }
            });
        } catch (Exception ignored) {
        }
    }

    private String getStoredServiceAccountJson() {
        String txt = getSharedPreferences(PREFS_ADMIN, MODE_PRIVATE)
                .getString(KEY_FCM_SERVICE_ACCOUNT, "");
        if (!txt.isEmpty()) return txt;
        try {
            java.io.InputStream is = getAssets().open("firebase-service-account.json");
            java.io.BufferedReader r = new java.io.BufferedReader(
                    new java.io.InputStreamReader(is, java.nio.charset.StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line).append('\n');
            return sb.toString().trim();
        } catch (Exception e) {
            return "";
        }
    }

    private String str(DataSnapshot snap) {
        Object v = snap.getValue();
        return v != null ? String.valueOf(v) : "";
    }

    private void updateEmpty() {
        emptyView.setVisibility(messages.isEmpty() ? View.VISIBLE : View.GONE);
    }

    private void scrollToBottom() {
        if (messages.isEmpty()) return;
        messageList.post(() -> messageList.smoothScrollToPosition(messages.size() - 1));
    }

    @Override
    protected void onDestroy() {
        if (userRef != null && userNameListener != null) {
            try {
                userRef.child("name").removeEventListener(userNameListener);
            } catch (Exception ignored) {
            }
        }
        if (msgRef != null && msgListener != null) {
            try {
                msgRef.removeEventListener(msgListener);
            } catch (Exception ignored) {
            }
        }
        super.onDestroy();
    }

    private class MessageAdapter extends RecyclerView.Adapter<MessageAdapter.VH> {

        @NonNull
        @Override
        public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_chat_message, parent, false);
            return new VH(v);
        }

        @Override
        public void onBindViewHolder(@NonNull VH h, int position) {
            ChatMessage m = messages.get(position);
            boolean isAdmin = "admin".equals(m.sender);
            h.text.setText(m.text);

            LinearLayout row = h.itemView.findViewById(R.id.row);
            LinearLayout bubble = h.itemView.findViewById(R.id.bubbleWrap);

            if (isAdmin) {
                row.setGravity(Gravity.END);
                row.setPadding(dp(56), dp(4), dp(4), dp(4));
                bubble.setBackgroundResource(R.drawable.bg_chat_admin);
                h.text.setTextColor(getColor(R.color.codeweave_text_primary));
            } else {
                row.setGravity(Gravity.START);
                row.setPadding(dp(4), dp(4), dp(56), dp(4));
                bubble.setBackgroundResource(R.drawable.bg_chat_user);
                h.text.setTextColor(getColor(R.color.codeweave_text_primary));
            }

            h.time.setText(formatTime(m.ts));
            h.time.setVisibility(m.ts > 0 ? View.VISIBLE : View.GONE);
        }

        @Override
        public int getItemCount() {
            return messages.size();
        }

        private int dp(int v) {
            return Math.round(v * getResources().getDisplayMetrics().density);
        }

        class VH extends RecyclerView.ViewHolder {
            TextView text, time;

            VH(@NonNull View itemView) {
                super(itemView);
                text = itemView.findViewById(R.id.messageText);
                time = itemView.findViewById(R.id.messageTime);
            }
        }
    }

    private String formatTime(long ts) {
        if (ts <= 0) return "";
        java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("dd MMM, hh:mm a", java.util.Locale.US);
        return f.format(new java.util.Date(ts));
    }
}
