package com.codeweave.admin.core;

import com.google.firebase.database.DataSnapshot;

public class User {

    public String uid;
    public String name;
    public String email;
    public String photo;
    public String device;
    public String app;
    public String appVersion;
    public long appVersionCode;
    public long createdAt;
    public long lastSeen;
    public String plan = "free";
    public long planExpiry;
    public String planName;
    public long requestsUsed;
    public long photosUsed;
    public long lastResetAt;
    public long opens;
    public boolean online;
    public long lastActive;
    public long sessionStart;
    public long sessionEnd;
    public long sessionDurationMs;
    public long totalDurationMs;
    public long sessionCount;

    public static User parse(String uid, DataSnapshot snap) {
        User u = new User();
        u.uid = uid;
        u.name = snap.child("name").getValue(String.class);
        u.email = snap.child("email").getValue(String.class);
        u.photo = snap.child("photo").getValue(String.class);
        u.device = snap.child("device").getValue(String.class);
        u.app = snap.child("app").getValue(String.class);
        u.appVersion = snap.child("appVersion").getValue(String.class);
        Long avc = snap.child("appVersionCode").getValue(Long.class);
        u.appVersionCode = avc != null ? avc : 0L;
        Long ca = snap.child("createdAt").getValue(Long.class);
        Long ls = snap.child("lastSeen").getValue(Long.class);
        u.createdAt = ca != null ? ca : 0L;
        u.lastSeen = ls != null ? ls : 0L;
        String p = snap.child("plan").getValue(String.class);
        if (p != null && !p.trim().isEmpty()) u.plan = p;
        Long ru = snap.child("requestsUsed").getValue(Long.class);
        Long pu = snap.child("photosUsed").getValue(Long.class);
        Long lr = snap.child("lastResetAt").getValue(Long.class);
        Long pe = snap.child("planExpiry").getValue(Long.class);
        u.requestsUsed = ru != null ? ru : 0L;
        u.photosUsed = pu != null ? pu : 0L;
        u.lastResetAt = lr != null ? lr : 0L;
        u.planExpiry = pe != null ? pe : 0L;
        u.planName = snap.child("planName").getValue(String.class);
        Long op = snap.child("opens").getValue(Long.class);
        u.opens = op != null ? op : 0L;
        Boolean on = snap.child("online").getValue(Boolean.class);
        u.online = on != null && on;
        Long la = snap.child("lastActive").getValue(Long.class);
        Long ss = snap.child("sessionStart").getValue(Long.class);
        Long se = snap.child("sessionEnd").getValue(Long.class);
        Long sd = snap.child("sessionDurationMs").getValue(Long.class);
        Long td = snap.child("totalDurationMs").getValue(Long.class);
        Long sc = snap.child("sessionCount").getValue(Long.class);
        u.lastActive = la != null ? la : 0L;
        u.sessionStart = ss != null ? ss : 0L;
        u.sessionEnd = se != null ? se : 0L;
        u.sessionDurationMs = sd != null ? sd : 0L;
        u.totalDurationMs = td != null ? td : 0L;
        u.sessionCount = sc != null ? sc : 0L;
        // Old clients only wrote lastSeen; fall back so the panel still shows something.
        if (u.lastActive == 0) u.lastActive = u.lastSeen;
        if (u.planName == null) u.planName = "";
        if (u.name == null || u.name.trim().isEmpty()) u.name = "User";
        if (u.email == null) u.email = "";
        return u;
    }

    private static final long ONLINE_WINDOW = 3L * 60 * 1000L;

    /**
     * Online means: client sent online=true and its heartbeat is still fresh.
     * If the app was killed without reporting, lastActive goes stale and we
     * show the user as offline instead of a permanent fake "online".
     */
    public boolean isOnline() {
        if (!online) return false;
        if (lastActive <= 0) return false;
        return System.currentTimeMillis() - lastActive <= ONLINE_WINDOW;
    }

    /** Session length: live duration if still open, otherwise the last closed session. */
    public long sessionDuration(long now) {
        if (isOnline()) {
            return sessionStart > 0 ? Math.max(0L, now - sessionStart) : 0L;
        }
        return sessionDurationMs;
    }

    public boolean isPaid() {
        if (!"paid".equals(plan)) return false;
        if (planExpiry > 0 && System.currentTimeMillis() > planExpiry) return false;
        return true;
    }

    public String getInitial() {
        String n = name.trim();
        if (n.isEmpty()) return "?";
        return n.substring(0, 1).toUpperCase();
    }

    public boolean matches(String query) {
        if (query == null || query.trim().isEmpty()) return true;
        String q = query.trim().toLowerCase();
        return (name != null && name.toLowerCase().contains(q))
                || (email != null && email.toLowerCase().contains(q))
                || (uid != null && uid.toLowerCase().contains(q));
    }
}
