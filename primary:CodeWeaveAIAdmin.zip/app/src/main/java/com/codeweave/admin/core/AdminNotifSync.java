package com.codeweave.admin.core;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class AdminNotifSync {
    public static final String NOTIF_PATH = "notifications";

    public interface Callback {
        void onDone(int count);
    }

    private AdminNotifSync() {}

    public static void writeToUser(String uid, String type, String title, String message) {
        if (uid == null || uid.isEmpty()) return;
        Map<String, Object> data = new HashMap<>();
        data.put("type", type);
        data.put("title", title);
        data.put("message", message);
        data.put("createdAt", System.currentTimeMillis());
        data.put("read", false);
        FirebaseDatabase.getInstance().getReference(NOTIF_PATH).child(uid).push().setValue(data);
    }

    public static void writeToAll(String type, String title, String message, Callback cb) {
        final DatabaseReference usersRef = FirebaseDatabase.getInstance().getReference("users");
        usersRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snap) {
                final List<String> uids = new ArrayList<>();
                for (DataSnapshot child : snap.getChildren()) {
                    if (child.getKey() != null) uids.add(child.getKey());
                }
                if (uids.isEmpty()) {
                    if (cb != null) cb.onDone(0);
                    return;
                }
                final DatabaseReference notifRef = FirebaseDatabase.getInstance().getReference(NOTIF_PATH);
                final int[] remaining = {uids.size()};
                final int[] written = {0};
                for (String uid : uids) {
                    Map<String, Object> data = new HashMap<>();
                    data.put("type", type);
                    data.put("title", title);
                    data.put("message", message);
                    data.put("createdAt", System.currentTimeMillis());
                    data.put("read", false);
                    notifRef.child(uid).push().setValue(data, (error, ref) -> {
                        if (error == null) written[0]++;
                        remaining[0]--;
                        if (remaining[0] == 0 && cb != null) cb.onDone(written[0]);
                    });
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                if (cb != null) cb.onDone(0);
            }
        });
    }
}