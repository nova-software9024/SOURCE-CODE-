package com.codeweave.admin.ui;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.codeweave.admin.R;
import com.codeweave.admin.core.AdminNotifSync;
import com.codeweave.admin.core.PushSender;
import com.codeweave.admin.util.ClickAnimationUtil;
import com.google.firebase.database.FirebaseDatabase;

public class PushActivity extends BaseSettingsActivity {

    private static final String PREFS_ADMIN = "admin_prefs";
    private static final String KEY_FCM_SERVICE_ACCOUNT = "fcm_service_account";

    private EditText pushServiceJsonInput, pushTitleInput, pushMessageInput, pushTargetUidInput;
    private TextView savePushCredsBtn, sendPushBtn, pushStatusText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_push);
        setupHeader(R.string.menu_push);

        pushServiceJsonInput = findViewById(R.id.pushServiceJsonInput);
        pushTitleInput = findViewById(R.id.pushTitleInput);
        pushMessageInput = findViewById(R.id.pushMessageInput);
        pushTargetUidInput = findViewById(R.id.pushTargetUidInput);
        savePushCredsBtn = findViewById(R.id.savePushCredsBtn);
        sendPushBtn = findViewById(R.id.sendPushBtn);
        pushStatusText = findViewById(R.id.pushStatusText);

        SharedPreferences prefs = getSharedPreferences(PREFS_ADMIN, MODE_PRIVATE);
        String savedJson = prefs.getString(KEY_FCM_SERVICE_ACCOUNT, "");
        if (!savedJson.isEmpty()) {
            pushServiceJsonInput.setText(savedJson);
        } else {
            String assetJson = readAssetServiceAccountJson();
            if (!assetJson.isEmpty()) {
                pushServiceJsonInput.setText(assetJson);
            }
        }

        savePushCredsBtn.setOnClickListener(v -> savePushCredentials());
        ClickAnimationUtil.apply(savePushCredsBtn);
        sendPushBtn.setOnClickListener(v -> sendPush());
        ClickAnimationUtil.apply(sendPushBtn);
    }

    private String readAssetServiceAccountJson() {
        try {
            java.io.InputStream is = getAssets().open("firebase-service-account.json");
            java.io.BufferedReader r = new java.io.BufferedReader(
                    new java.io.InputStreamReader(is, java.nio.charset.StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line).append('\n');
            return sb.toString().trim();
        } catch (Exception e) {
            return "";
        }
    }

    private String getServiceAccountJson() {
        String txt = pushServiceJsonInput.getText().toString().trim();
        if (!txt.isEmpty()) return txt;
        return readAssetServiceAccountJson();
    }

    private void savePushCredentials() {
        String json = getServiceAccountJson();
        if (json.isEmpty()) {
            Toast.makeText(this, R.string.push_creds_required, Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            PushSender.parseServiceAccount(json);
        } catch (Exception e) {
            Toast.makeText(this, R.string.push_creds_invalid, Toast.LENGTH_LONG).show();
            return;
        }
        getSharedPreferences(PREFS_ADMIN, MODE_PRIVATE)
                .edit().putString(KEY_FCM_SERVICE_ACCOUNT, json).apply();
        setPushStatus(R.string.push_creds_saved, true);
    }

    private void sendPush() {
        String json = getServiceAccountJson();
        if (json.isEmpty()) {
            Toast.makeText(this, R.string.push_creds_required, Toast.LENGTH_SHORT).show();
            return;
        }
        final PushSender.ServiceAccount sa;
        try {
            sa = PushSender.parseServiceAccount(json);
        } catch (Exception e) {
            Toast.makeText(this, R.string.push_creds_invalid, Toast.LENGTH_LONG).show();
            return;
        }
        final String title = pushTitleInput.getText().toString().trim();
        final String body = pushMessageInput.getText().toString().trim();
        if (title.isEmpty() || body.isEmpty()) {
            Toast.makeText(this, R.string.push_content_required, Toast.LENGTH_SHORT).show();
            return;
        }
        final String targetUid = pushTargetUidInput.getText().toString().trim();

        sendPushBtn.setEnabled(false);

        final PushSender.SendCallback cb = (success, message) -> runOnUiThread(() -> {
            sendPushBtn.setEnabled(true);
            pushStatusText.setText(message);
            pushStatusText.setTextColor(getColor(success ? R.color.codeweave_success : R.color.error));
            pushStatusText.setVisibility(android.view.View.VISIBLE);
        });

        if (targetUid.isEmpty()) {
            PushSender.sendToAll(sa, title, body, (success, message) -> {
                AdminNotifSync.writeToAll("push", title, body, saved ->
                        runOnUiThread(() -> {
                            sendPushBtn.setEnabled(true);
                            pushStatusText.setText(message + "\nSaved to " + saved + " users' notification section.");
                            pushStatusText.setTextColor(getColor(success ? R.color.codeweave_success : R.color.error));
                            pushStatusText.setVisibility(android.view.View.VISIBLE);
                        }));
            });
        } else {
            AdminNotifSync.writeToUser(targetUid, "push", title, body);
            FirebaseDatabase.getInstance().getReference("users")
                    .child(targetUid).child("fcmToken").get()
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful() && task.getResult() != null) {
                            String token = task.getResult().getValue(String.class);
                            if (token == null || token.isEmpty()) {
                                runOnUiThread(() -> {
                                    sendPushBtn.setEnabled(true);
                                    Toast.makeText(this, R.string.push_no_token, Toast.LENGTH_LONG).show();
                                });
                                return;
                            }
                            PushSender.sendToToken(sa, token, title, body, cb);
                        } else {
                            runOnUiThread(() -> {
                                sendPushBtn.setEnabled(true);
                                Toast.makeText(this, R.string.push_no_token, Toast.LENGTH_LONG).show();
                            });
                        }
                    });
        }
    }

    private void setPushStatus(int res, boolean success) {
        pushStatusText.setText(res);
        pushStatusText.setTextColor(getColor(success ? R.color.codeweave_success : R.color.codeweave_text_secondary));
        pushStatusText.setVisibility(android.view.View.VISIBLE);
    }
}
