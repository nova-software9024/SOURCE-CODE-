package com.codeweave.admin.ui;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.widget.SwitchCompat;

import com.codeweave.admin.R;
import com.codeweave.admin.util.ClickAnimationUtil;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

public class AppUpdateActivity extends BaseSettingsActivity {

    private SwitchCompat forceUpdateSwitch;
    private EditText minVersionInput, latestVersionInput, updateUrlInput, updateMessageInput;
    private TextView saveBtn, statusText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);
        setupHeader(R.string.menu_update);

        forceUpdateSwitch = findViewById(R.id.forceUpdateSwitch);
        minVersionInput = findViewById(R.id.minVersionInput);
        latestVersionInput = findViewById(R.id.latestVersionInput);
        updateUrlInput = findViewById(R.id.updateUrlInput);
        updateMessageInput = findViewById(R.id.updateMessageInput);
        saveBtn = findViewById(R.id.saveBtn);
        statusText = findViewById(R.id.statusText);

        configRef.child("appUpdate").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot au) {
                Boolean fuEnabled = au.child("enabled").getValue(Boolean.class);
                forceUpdateSwitch.setChecked(fuEnabled != null && fuEnabled);
                loadIntoField(minVersionInput, au.child("minVersion"));
                loadIntoField(latestVersionInput, au.child("latestVersion"));
                loadIntoField(updateUrlInput, au.child("url"));
                loadIntoField(updateMessageInput, au.child("message"));
            }

            @Override
            public void onCancelled(DatabaseError error) {
            }
        });

        saveBtn.setOnClickListener(v -> save());
        ClickAnimationUtil.apply(saveBtn);
    }

    private void save() {
        Map<String, Object> appUpdate = new HashMap<>();
        appUpdate.put("enabled", forceUpdateSwitch.isChecked());
        appUpdate.put("minVersion", minVersionInput.getText().toString().trim());
        appUpdate.put("latestVersion", latestVersionInput.getText().toString().trim());
        appUpdate.put("url", updateUrlInput.getText().toString().trim());
        appUpdate.put("message", updateMessageInput.getText().toString().trim());

        saveBtn.setEnabled(false);
        configRef.child("appUpdate").updateChildren(appUpdate)
                .addOnSuccessListener(a -> {
                    saveBtn.setEnabled(true);
                    statusText.setText(R.string.settings_saved);
                    statusText.setVisibility(View.VISIBLE);
                })
                .addOnFailureListener(e -> {
                    saveBtn.setEnabled(true);
                    toastSaved(false);
                });
    }
}
