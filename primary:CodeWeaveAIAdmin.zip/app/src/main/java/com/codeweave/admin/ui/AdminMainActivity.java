package com.codeweave.admin.ui;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.codeweave.admin.R;
import com.codeweave.admin.core.AdminAuth;
import com.codeweave.admin.core.Payment;
import com.codeweave.admin.core.PushSender;
import com.codeweave.admin.core.User;
import com.codeweave.admin.util.ClickAnimationUtil;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class AdminMainActivity extends AppCompatActivity {

    private UserAdapter adapter;
    private PaymentAdapter paymentAdapter;

    private ValueEventListener usersListener;
    private ValueEventListener adminsListener;
    private ValueEventListener paymentsListener;

    private DatabaseReference usersRef;
    private DatabaseReference adminsRef;
    private DatabaseReference paymentsRef;

    private TextView totalUsersText, paidUsersText, adminCountText, emptyText;
    private TextView pendingPaymentsText, paymentsEmptyText, incomeText, paymentsIncomeText;
    private LinearLayout emptyView, paymentsEmptyView;
    private FrameLayout progressOverlay;
    private EditText searchInput;
    private SwipeRefreshLayout swipeRefresh;
    private boolean firstLoad = true;

    private LinearLayout tabUsers, tabPayments, tabSettings, tabPro, tabStats;
    private TextView tabUsersText, tabPaymentsText, tabSettingsText, tabProText, tabStatsText;
    private View tabUsersLine, tabPaymentsLine, tabSettingsLine, tabProLine, tabStatsLine;
    private LinearLayout usersPanel, paymentsPanel, proPanel, statsPanel;
    private UserAdapter proAdapter;
    private TextView proCountText;
    private LinearLayout proEmptyView;

    private TextView chipSortActivity, chipSortNewest, chipSortTime, chipSortName;
    private static final String PREFS_SORT = "admin_sort_prefs";
    private static final String KEY_SORT = "sort_mode";

    private ChartView incomeChart, usersChart, dauChart;
    private TextView statsTodayOpeners, statsTodayPaid;
    private ValueEventListener statsDailyListener;
    private DatabaseReference statsDailyRef;

    private static final String PREFS_ADMIN = "admin_prefs";
    private static final String KEY_FCM_SERVICE_ACCOUNT = "fcm_service_account";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_main);
        getWindow().setStatusBarColor(getColor(R.color.codeweave_bg));

        totalUsersText = findViewById(R.id.totalUsersText);
        paidUsersText = findViewById(R.id.paidUsersText);
        adminCountText = findViewById(R.id.adminCountText);
        emptyView = findViewById(R.id.emptyView);
        emptyText = findViewById(R.id.emptyText);
        progressOverlay = findViewById(R.id.progressOverlay);
        searchInput = findViewById(R.id.searchInput);
        swipeRefresh = findViewById(R.id.swipeRefresh);

        pendingPaymentsText = findViewById(R.id.pendingPaymentsText);
        paymentsEmptyView = findViewById(R.id.paymentsEmptyView);
        paymentsEmptyText = findViewById(R.id.paymentsEmptyText);
        incomeText = findViewById(R.id.incomeText);
        paymentsIncomeText = findViewById(R.id.paymentsIncomeText);

        View btnLogout = findViewById(R.id.btnLogout);
        btnLogout.setOnClickListener(v -> showLogoutConfirm());
        ClickAnimationUtil.apply(btnLogout);

        RecyclerView list = findViewById(R.id.usersList);
        list.setLayoutManager(new LinearLayoutManager(this));
        adapter = new UserAdapter();
        list.setAdapter(adapter);

        RecyclerView pList = findViewById(R.id.paymentsList);
        pList.setLayoutManager(new LinearLayoutManager(this));
        paymentAdapter = new PaymentAdapter();
        paymentAdapter.setListener(new PaymentAdapter.PaymentActionListener() {
            @Override
            public void onApprove(Payment p) {
                approvePayment(p);
            }

            @Override
            public void onReject(Payment p) {
                rejectPayment(p);
            }
        });
        pList.setAdapter(paymentAdapter);

        RecyclerView proList = findViewById(R.id.proList);
        proList.setLayoutManager(new LinearLayoutManager(this));
        proAdapter = new UserAdapter();
        proList.setAdapter(proAdapter);

        swipeRefresh.setColorSchemeResources(R.color.codeweave_gradient_start);
        swipeRefresh.setOnRefreshListener(() -> {
            attachListeners();
            swipeRefresh.setRefreshing(false);
        });

        initSortChips();

        searchInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {
                adapter.setFilter(s.toString());
                updateEmptyState(s.toString());
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        initTabs();

        FirebaseDatabase db = FirebaseDatabase.getInstance();
        usersRef = db.getReference("users");
        adminsRef = db.getReference("admins");
        paymentsRef = db.getReference("payments");

        if (!AdminAuth.isSignedIn()) {
            goToLogin();
            return;
        }
        registerFcmToken();
        attachListeners();
    }

    private void initSortChips() {
        chipSortActivity = findViewById(R.id.chipSortActivity);
        chipSortNewest = findViewById(R.id.chipSortNewest);
        chipSortTime = findViewById(R.id.chipSortTime);
        chipSortName = findViewById(R.id.chipSortName);

        int saved = getSharedPreferences(PREFS_SORT, MODE_PRIVATE).getInt(KEY_SORT, UserAdapter.SORT_ACTIVITY);
        applySort(saved, false);

        chipSortActivity.setOnClickListener(v -> applySort(UserAdapter.SORT_ACTIVITY, true));
        chipSortNewest.setOnClickListener(v -> applySort(UserAdapter.SORT_NEWEST, true));
        chipSortTime.setOnClickListener(v -> applySort(UserAdapter.SORT_TIME, true));
        chipSortName.setOnClickListener(v -> applySort(UserAdapter.SORT_NAME, true));
        ClickAnimationUtil.apply(chipSortActivity);
        ClickAnimationUtil.apply(chipSortNewest);
        ClickAnimationUtil.apply(chipSortTime);
        ClickAnimationUtil.apply(chipSortName);
    }

    private void applySort(int mode, boolean persist) {
        adapter.setSortMode(mode);
        proAdapter.setSortMode(mode);
        highlightSortChip(mode);
        if (persist) {
            getSharedPreferences(PREFS_SORT, MODE_PRIVATE)
                    .edit().putInt(KEY_SORT, mode).apply();
        }
    }

    private void highlightSortChip(int mode) {
        styleChip(chipSortActivity, mode == UserAdapter.SORT_ACTIVITY);
        styleChip(chipSortNewest, mode == UserAdapter.SORT_NEWEST);
        styleChip(chipSortTime, mode == UserAdapter.SORT_TIME);
        styleChip(chipSortName, mode == UserAdapter.SORT_NAME);
    }

    private void styleChip(TextView chip, boolean active) {
        if (active) {
            chip.setBackgroundResource(R.drawable.bg_glass_button);
            chip.setTextColor(getColor(R.color.codeweave_gradient_start));
        } else {
            chip.setBackgroundResource(R.drawable.bg_glass_button_outline);
            chip.setTextColor(getColor(R.color.codeweave_text_secondary));
        }
    }

    private void registerFcmToken() {
        try {
            com.google.firebase.messaging.FirebaseMessaging.getInstance().getToken()
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful() && task.getResult() != null) {
                            String uid = com.google.firebase.auth.FirebaseAuth.getInstance().getCurrentUser() != null
                                    ? com.google.firebase.auth.FirebaseAuth.getInstance().getCurrentUser().getUid() : null;
                            if (uid != null) {
                                FirebaseDatabase.getInstance().getReference("admins").child(uid)
                                        .child("fcmToken").setValue(task.getResult());
                            }
                        }
                    });
        } catch (Exception ignored) {
        }
    }

    private void initTabs() {
        tabUsers = findViewById(R.id.tabUsers);
        tabPayments = findViewById(R.id.tabPayments);
        tabSettings = findViewById(R.id.tabSettings);
        tabPro = findViewById(R.id.tabPro);
        tabStats = findViewById(R.id.tabStats);
        tabUsersText = findViewById(R.id.tabUsersText);
        tabPaymentsText = findViewById(R.id.tabPaymentsText);
        tabSettingsText = findViewById(R.id.tabSettingsText);
        tabProText = findViewById(R.id.tabProText);
        tabStatsText = findViewById(R.id.tabStatsText);
        tabUsersLine = findViewById(R.id.tabUsersLine);
        tabPaymentsLine = findViewById(R.id.tabPaymentsLine);
        tabSettingsLine = findViewById(R.id.tabSettingsLine);
        tabProLine = findViewById(R.id.tabProLine);
        tabStatsLine = findViewById(R.id.tabStatsLine);
        usersPanel = findViewById(R.id.usersPanel);
        paymentsPanel = findViewById(R.id.paymentsPanel);
        proPanel = findViewById(R.id.proPanel);
        statsPanel = findViewById(R.id.statsPanel);
        proCountText = findViewById(R.id.proCountText);
        proEmptyView = findViewById(R.id.proEmptyView);
        incomeChart = findViewById(R.id.incomeChart);
        usersChart = findViewById(R.id.usersChart);
        dauChart = findViewById(R.id.dauChart);
        statsTodayOpeners = findViewById(R.id.statsTodayOpeners);
        statsTodayPaid = findViewById(R.id.statsTodayPaid);

        tabUsers.setOnClickListener(v -> selectTab(0));
        tabPro.setOnClickListener(v -> selectTab(1));
        tabPayments.setOnClickListener(v -> selectTab(2));
        tabStats.setOnClickListener(v -> selectTab(3));
        tabSettings.setOnClickListener(v ->
                startActivity(new Intent(this, SettingsMenuActivity.class)));
        selectTab(0);
    }

    private void selectTab(int index) {
        usersPanel.setVisibility(index == 0 ? View.VISIBLE : View.GONE);
        proPanel.setVisibility(index == 1 ? View.VISIBLE : View.GONE);
        paymentsPanel.setVisibility(index == 2 ? View.VISIBLE : View.GONE);
        statsPanel.setVisibility(index == 3 ? View.VISIBLE : View.GONE);

        tabUsersText.setTextColor(getColor(index == 0 ? R.color.codeweave_gradient_start : R.color.codeweave_text_secondary));
        tabProText.setTextColor(getColor(index == 1 ? R.color.codeweave_gradient_start : R.color.codeweave_text_secondary));
        tabPaymentsText.setTextColor(getColor(index == 2 ? R.color.codeweave_gradient_start : R.color.codeweave_text_secondary));
        tabStatsText.setTextColor(getColor(index == 3 ? R.color.codeweave_gradient_start : R.color.codeweave_text_secondary));
        tabSettingsText.setTextColor(getColor(R.color.codeweave_text_secondary));
        tabUsersText.setTypeface(tabUsersText.getTypeface(), index == 0 ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
        tabProText.setTypeface(tabProText.getTypeface(), index == 1 ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
        tabPaymentsText.setTypeface(tabPaymentsText.getTypeface(), index == 2 ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
        tabStatsText.setTypeface(tabStatsText.getTypeface(), index == 3 ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
        tabSettingsText.setTypeface(tabSettingsText.getTypeface(), android.graphics.Typeface.NORMAL);
        tabUsersLine.setBackgroundColor(getColor(index == 0 ? R.color.codeweave_gradient_start : android.R.color.transparent));
        tabProLine.setBackgroundColor(getColor(index == 1 ? R.color.codeweave_gradient_start : android.R.color.transparent));
        tabPaymentsLine.setBackgroundColor(getColor(index == 2 ? R.color.codeweave_gradient_start : android.R.color.transparent));
        tabStatsLine.setBackgroundColor(getColor(index == 3 ? R.color.codeweave_gradient_start : android.R.color.transparent));
        tabSettingsLine.setBackgroundColor(android.R.color.transparent);
    }

    private String readAssetServiceAccountJson() {
        try {
            java.io.InputStream is = getAssets().open("firebase-service-account.json");
            java.io.BufferedReader r = new java.io.BufferedReader(
                    new java.io.InputStreamReader(is, java.nio.charset.StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line).append('\n');
            return sb.toString().trim();
        } catch (Exception e) {
            return "";
        }
    }

    private String getStoredServiceAccountJson() {
        String txt = getSharedPreferences(PREFS_ADMIN, MODE_PRIVATE)
                .getString(KEY_FCM_SERVICE_ACCOUNT, "");
        if (!txt.isEmpty()) return txt;
        return readAssetServiceAccountJson();
    }

    private void attachListeners() {
        detachListeners();

        usersListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                List<User> users = new ArrayList<>();
                List<User> proUsers = new ArrayList<>();
                int paid = 0;
                long[] newUsersPerDay = new long[7];
                for (DataSnapshot child : snapshot.getChildren()) {
                    User u = User.parse(child.getKey(), child);
                    users.add(u);
                    if (u.isPaid()) {
                        paid++;
                        proUsers.add(u);
                    }
                    int idx = dayIndex(u.createdAt);
                    if (idx >= 0) newUsersPerDay[idx]++;
                }
                adapter.setData(users);
                String query = searchInput.getText().toString();
                adapter.setFilter(query);
                totalUsersText.setText(String.valueOf(users.size()));
                paidUsersText.setText(String.valueOf(paid));
                updateEmptyState(query);

                proAdapter.setData(proUsers);
                proCountText.setText(getString(R.string.pro_users_title) + " (" + proUsers.size() + ")");
                proEmptyView.setVisibility(proUsers.isEmpty() ? View.VISIBLE : View.GONE);

                if (usersChart != null) usersChart.setData(buildChart(pointsForLabels(), newUsersPerDay));

                if (firstLoad) {
                    firstLoad = false;
                    if (progressOverlay != null) progressOverlay.setVisibility(View.GONE);
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                if (firstLoad) {
                    firstLoad = false;
                    if (progressOverlay != null) progressOverlay.setVisibility(View.GONE);
                }
            }
        };
        usersRef.addValueEventListener(usersListener);

        adminsListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                adminCountText.setText(String.valueOf(snapshot.getChildrenCount()));
            }

            @Override
            public void onCancelled(DatabaseError error) {
            }
        };
        adminsRef.addValueEventListener(adminsListener);

        paymentsListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                List<Payment> payments = new ArrayList<>();
                int pending = 0;
                double approvedTotal = 0d;
                double pendingTotal = 0d;
                double todayIncome = 0d;
                String todayKey = fmtDay(System.currentTimeMillis());
                double[] incomePerDay = new double[7];
                for (DataSnapshot child : snapshot.getChildren()) {
                    Payment p = Payment.parse(child.getKey(), child);
                    payments.add(p);
                    if (p.isPending()) {
                        pending++;
                        pendingTotal += parseAmount(p.amount);
                    } else if ("approved".equals(p.status)) {
                        approvedTotal += parseAmount(p.amount);
                        double amt = parseAmount(p.amount);
                        int idx = dayIndex(p.createdAt);
                        if (idx >= 0) incomePerDay[idx] += amt;
                        if (fmtDay(p.createdAt).equals(todayKey)) todayIncome += amt;
                    }
                }
                paymentAdapter.setData(payments);
                pendingPaymentsText.setText(String.valueOf(pending));
                String approvedStr = formatAmount(approvedTotal);
                String pendingStr = formatAmount(pendingTotal);
                if (incomeText != null) incomeText.setText("₹" + approvedStr);
                if (paymentsIncomeText != null) {
                    paymentsIncomeText.setText(approvedTotal > 0 || pendingTotal > 0
                            ? getString(R.string.income_approved, approvedStr) + "   ·   "
                                + getString(R.string.income_pending, pendingStr)
                            : "—");
                }
                if (statsTodayPaid != null) statsTodayPaid.setText("₹" + formatAmount(todayIncome));
                if (incomeChart != null) incomeChart.setData(buildChart(pointsForLabels(), incomePerDay));
                if (payments.isEmpty()) {
                    paymentsEmptyText.setText(R.string.empty_payments);
                    paymentsEmptyView.setVisibility(View.VISIBLE);
                } else {
                    paymentsEmptyView.setVisibility(View.GONE);
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
            }
        };
        paymentsRef.addValueEventListener(paymentsListener);

        attachStatsDailyListener();
    }

    private void attachStatsDailyListener() {
        if (statsDailyRef != null && statsDailyListener != null) {
            statsDailyRef.removeEventListener(statsDailyListener);
            statsDailyListener = null;
        }
        if (statsDailyRef == null) {
            statsDailyRef = FirebaseDatabase.getInstance().getReference("stats").child("daily");
        }
        statsDailyListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                long[] dauPerDay = new long[7];
                for (int i = 6; i >= 0; i--) {
                    String day = fmtDay(System.currentTimeMillis() - i * 86400000L);
                    DataSnapshot daySnap = snapshot.child(day);
                    dauPerDay[i] = daySnap.getChildrenCount();
                }
                if (statsTodayOpeners != null) statsTodayOpeners.setText(String.valueOf(dauPerDay[6]));
                if (dauChart != null) dauChart.setData(buildChart(dauLabels(), dauPerDay));
            }

            @Override
            public void onCancelled(DatabaseError error) {
            }
        };
        statsDailyRef.addValueEventListener(statsDailyListener);
    }

    private void detachListeners() {
        if (usersRef != null && usersListener != null) usersRef.removeEventListener(usersListener);
        if (adminsRef != null && adminsListener != null) adminsRef.removeEventListener(adminsListener);
        if (paymentsRef != null && paymentsListener != null) paymentsRef.removeEventListener(paymentsListener);
        if (statsDailyRef != null && statsDailyListener != null) statsDailyRef.removeEventListener(statsDailyListener);
    }

    private String fmtDay(long ts) {
        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd", Locale.US);
        return sdf.format(new java.util.Date(ts));
    }

    private int dayIndex(long ts) {
        if (ts <= 0) return -1;
        long now = System.currentTimeMillis();
        long dayStart = midnight();
        if (ts > now || ts < dayStart - 6 * 86400000L) return -1;
        long dayOffset = dayStart - ts;
        int daysAgo = (int) (dayOffset / 86400000L);
        int idx = 6 - daysAgo;
        return (idx < 0 || idx >= 7) ? -1 : idx;
    }

    private long midnight() {
        java.util.Calendar c = java.util.Calendar.getInstance();
        c.set(java.util.Calendar.HOUR_OF_DAY, 0);
        c.set(java.util.Calendar.MINUTE, 0);
        c.set(java.util.Calendar.SECOND, 0);
        c.set(java.util.Calendar.MILLISECOND, 0);
        return c.getTimeInMillis();
    }

    private String[] pointsForLabels() {
        return dayLabels();
    }

    private String[] dauLabels() {
        return dayLabels();
    }

    private String[] dayLabels() {
        String[] out = new String[7];
        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("EEE", Locale.US);
        for (int i = 6; i >= 0; i--) {
            out[i] = sdf.format(new java.util.Date(System.currentTimeMillis() - i * 86400000L));
        }
        return out;
    }

    private List<ChartView.DataPoint> buildChart(String[] labels, double[] values) {
        List<ChartView.DataPoint> list = new ArrayList<>();
        int n = Math.min(labels.length, values.length);
        for (int i = 0; i < n; i++) {
            list.add(new ChartView.DataPoint(labels[i], (float) values[i]));
        }
        return list;
    }

    private List<ChartView.DataPoint> buildChart(String[] labels, long[] values) {
        List<ChartView.DataPoint> list = new ArrayList<>();
        int n = Math.min(labels.length, values.length);
        for (int i = 0; i < n; i++) {
            list.add(new ChartView.DataPoint(labels[i], (float) values[i]));
        }
        return list;
    }

    private double parseAmount(String amount) {
        if (amount == null || amount.trim().isEmpty()) return 0d;
        String clean = amount.replaceAll("[^0-9.,]", "");
        if (clean.isEmpty()) return 0d;
        // "1,999.50" / "1,999" -> comma is a thousands separator
        if (clean.contains(",")) {
            clean = clean.replace(",", "");
        }
        try {
            return Double.parseDouble(clean);
        } catch (NumberFormatException e) {
            return 0d;
        }
    }

    private String formatAmount(Double total) {
        return String.format(Locale.US, "%,.0f", total == null ? 0d : total);
    }

    private void approvePayment(Payment p) {
        if (p.userId == null || p.userId.isEmpty()) {
            Toast.makeText(this, R.string.uid_missing, Toast.LENGTH_SHORT).show();
            return;
        }
        showConfirm(R.string.approve_title, getString(R.string.approve_msg, p.userName), () -> {
            DatabaseReference userRef = FirebaseDatabase.getInstance().getReference("users").child(p.userId);
            userRef.child("planExpiry").addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot snap) {
                    long currentExpiry = 0;
                    Long val = snap.getValue(Long.class);
                    if (val != null) currentExpiry = val;
                    long base = Math.max(System.currentTimeMillis(), currentExpiry);
                    long planExpiry = p.planDays > 0 ? base + (long) p.planDays * 86400000L : 0L;
                    Map<String, Object> updates = new HashMap<>();
                    updates.put("payments/" + p.id + "/status", "approved");
                    updates.put("payments/" + p.id + "/reviewedAt", System.currentTimeMillis());
                    updates.put("users/" + p.userId + "/plan", "paid");
                    updates.put("users/" + p.userId + "/planExpiry", planExpiry);
                    if (p.planId != null && !p.planId.isEmpty()) {
                        updates.put("users/" + p.userId + "/planId", p.planId);
                    }
                    if (p.planName != null && !p.planName.isEmpty()) {
                        updates.put("users/" + p.userId + "/planName", p.planName);
                    }
                    FirebaseDatabase.getInstance().getReference().updateChildren(updates)
                            .addOnSuccessListener(a -> {
                                Toast.makeText(AdminMainActivity.this, R.string.approved_toast, Toast.LENGTH_SHORT).show();
                                sendPaidNotification(p);
                            })
                            .addOnFailureListener(e -> Toast.makeText(AdminMainActivity.this, R.string.action_failed, Toast.LENGTH_LONG).show());
                }

                @Override
                public void onCancelled(DatabaseError error) {
                    Toast.makeText(AdminMainActivity.this, R.string.action_failed, Toast.LENGTH_LONG).show();
                }
            });
        });
    }

    private void sendPaidNotification(Payment p) {
        try {
            String planLabel = p.planDays > 0
                    ? getString(R.string.admin_plan_days_label, p.planDays)
                    : getString(R.string.plan_lifetime);
            String name = p.userName != null && !p.userName.isEmpty() ? p.userName : "User";
            String email = p.userEmail != null ? p.userEmail : "";
            String title = getString(R.string.paid_notif_title);
            String message = getString(R.string.paid_notif_message, name, email, planLabel);

            Map<String, Object> record = new HashMap<>();
            record.put("type", "paid");
            record.put("title", title);
            record.put("message", message);
            record.put("createdAt", System.currentTimeMillis());
            record.put("read", false);
            record.put("name", name);
            record.put("email", email);
            record.put("planDays", p.planDays);
            record.put("planName", p.planName != null ? p.planName : "");
            FirebaseDatabase.getInstance().getReference("notifications")
                    .child(p.userId).child(p.id).setValue(record);

            final String serviceJson = getStoredServiceAccountJson();
            if (serviceJson.isEmpty()) return;
            DatabaseReference userRef = FirebaseDatabase.getInstance().getReference("users").child(p.userId);
            userRef.child("fcmToken").addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot snap) {
                    String token = snap.getValue(String.class);
                    if (token == null || token.isEmpty()) return;
                    try {
                        PushSender.ServiceAccount sa = PushSender.parseServiceAccount(serviceJson);
                        PushSender.sendToToken(sa, token, title, message, null);
                    } catch (Exception ignored) {
                    }
                }

                @Override
                public void onCancelled(DatabaseError error) {
                }
            });
        } catch (Exception ignored) {
        }
    }

    private void rejectPayment(Payment p) {
        showConfirm(R.string.reject_title, getString(R.string.reject_msg, p.userName), () -> {
            Map<String, Object> updates = new HashMap<>();
            updates.put("payments/" + p.id + "/status", "rejected");
            updates.put("payments/" + p.id + "/reviewedAt", System.currentTimeMillis());
            FirebaseDatabase.getInstance().getReference().updateChildren(updates)
                    .addOnSuccessListener(a -> Toast.makeText(this, R.string.rejected_toast, Toast.LENGTH_SHORT).show())
                    .addOnFailureListener(e -> Toast.makeText(this, R.string.action_failed, Toast.LENGTH_LONG).show());
        });
    }

    private void showConfirm(int titleRes, String message, Runnable onYes) {
        new AlertDialog.Builder(this)
                .setTitle(titleRes)
                .setMessage(message)
                .setNegativeButton(R.string.cancel, null)
                .setPositiveButton(R.string.ok, (d, w) -> onYes.run())
                .show();
    }

    private void updateEmptyState(String query) {
        boolean searching = query != null && !query.trim().isEmpty();
        if (adapter.getRawCount() == 0) {
            emptyText.setText(searching ? R.string.no_match : R.string.empty_users);
            emptyView.setVisibility(View.VISIBLE);
        } else if (adapter.getItemCount() == 0) {
            emptyText.setText(R.string.no_match);
            emptyView.setVisibility(View.VISIBLE);
        } else {
            emptyView.setVisibility(View.GONE);
        }
    }

    private void showLogoutConfirm() {
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_sign_out, null);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(dialogView)
                .create();
        View cancelBtn = dialogView.findViewById(R.id.dialogCancelBtn);
        cancelBtn.setOnClickListener(v -> dialog.dismiss());
        ClickAnimationUtil.apply(cancelBtn);
        View logoutBtn = dialogView.findViewById(R.id.dialogLogoutBtn);
        logoutBtn.setOnClickListener(v -> {
            dialog.dismiss();
            AdminAuth.signOut(this);
            goToLogin();
        });
        ClickAnimationUtil.apply(logoutBtn);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        }
        dialog.show();
    }

    private void goToLogin() {
        Intent intent = new Intent(this, AdminLoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        detachListeners();
    }
}
