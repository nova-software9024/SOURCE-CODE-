package com.codeweave.admin.ui;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.widget.SwitchCompat;

import com.codeweave.admin.R;
import com.codeweave.admin.util.ClickAnimationUtil;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

public class MaintenanceActivity extends BaseSettingsActivity {

    private SwitchCompat maintenanceSwitch;
    private EditText maintenanceMessageInput;
    private TextView saveBtn;
    private boolean loadingConfig = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maintenance);
        setupHeader(R.string.menu_maintenance);

        maintenanceSwitch = findViewById(R.id.maintenanceSwitch);
        maintenanceMessageInput = findViewById(R.id.maintenanceMessageInput);
        saveBtn = findViewById(R.id.saveBtn);

        configRef.child("maintenance").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot mt) {
                loadingConfig = true;
                Boolean enabled = mt.child("enabled").getValue(Boolean.class);
                maintenanceSwitch.setChecked(enabled != null && enabled);
                loadIntoField(maintenanceMessageInput, mt.child("message"));
                loadingConfig = false;
            }

            @Override
            public void onCancelled(DatabaseError error) {
            }
        });

        saveBtn.setOnClickListener(v -> save(false));
        ClickAnimationUtil.apply(saveBtn);
    }

    private void save(boolean fromSwitch) {
        Map<String, Object> mt = new HashMap<>();
        mt.put("enabled", maintenanceSwitch.isChecked());
        mt.put("message", maintenanceMessageInput.getText().toString().trim());
        if (!fromSwitch) saveBtn.setEnabled(false);
        configRef.child("maintenance").updateChildren(mt)
                .addOnSuccessListener(a -> {
                    if (!fromSwitch) saveBtn.setEnabled(true);
                    Toast.makeText(this, R.string.settings_saved, Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e -> {
                    if (!fromSwitch) saveBtn.setEnabled(true);
                    toastSaved(false);
                });
    }
}
