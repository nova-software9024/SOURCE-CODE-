package com.codeweave.admin.ui;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.codeweave.admin.R;
import com.codeweave.admin.core.User;
import com.codeweave.admin.util.ClickAnimationUtil;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class UserDetailActivity extends AppCompatActivity {

    public static final String EXTRA_UID = "uid";

    private final SimpleDateFormat fmt =
            new SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.ENGLISH);

    private DatabaseReference userRef;
    private ValueEventListener listener;

    private TextView avatar, name, emailTop, planBadge;
    private TextView email, uid, device, app, appVersion, appVersionCode, planStatus, planName,
            planExpiry, requestsUsed, photosUsed, lastReset, createdAt, lastSeen, opens,
            sessionStatus, sessionStart, sessionEnd, sessionDuration, lastActive,
            sessions, totalTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_detail);

        String userId = getIntent().getStringExtra(EXTRA_UID);
        if (userId == null || userId.trim().isEmpty()) {
            finish();
            return;
        }

        avatar = findViewById(R.id.detailAvatar);
        name = findViewById(R.id.detailName);
        emailTop = findViewById(R.id.detailEmailTop);
        planBadge = findViewById(R.id.detailPlanBadge);
        email = findViewById(R.id.detailEmail);
        uid = findViewById(R.id.detailUid);
        device = findViewById(R.id.detailDevice);
        app = findViewById(R.id.detailApp);
        appVersion = findViewById(R.id.detailAppVersion);
        appVersionCode = findViewById(R.id.detailAppVersionCode);
        planStatus = findViewById(R.id.detailPlanStatus);
        planName = findViewById(R.id.detailPlanName);
        planExpiry = findViewById(R.id.detailPlanExpiry);
        requestsUsed = findViewById(R.id.detailRequestsUsed);
        photosUsed = findViewById(R.id.detailPhotosUsed);
        lastReset = findViewById(R.id.detailLastReset);
        createdAt = findViewById(R.id.detailCreatedAt);
        lastSeen = findViewById(R.id.detailLastSeen);
        opens = findViewById(R.id.detailOpens);
        sessionStatus = findViewById(R.id.detailSessionStatus);
        sessionStart = findViewById(R.id.detailSessionStart);
        sessionEnd = findViewById(R.id.detailSessionEnd);
        sessionDuration = findViewById(R.id.detailSessionDuration);
        lastActive = findViewById(R.id.detailLastActive);
        sessions = findViewById(R.id.detailSessions);
        totalTime = findViewById(R.id.detailTotalTime);

        TextView back = findViewById(R.id.backBtn);
        if (back != null) {
            back.setOnClickListener(v -> finish());
            ClickAnimationUtil.apply(back);
        }
        TextView title = findViewById(R.id.pageTitle);
        if (title != null) title.setText(R.string.user_detail_title);

        TextView copyBtn = findViewById(R.id.copyUidBtn);
        copyBtn.setOnClickListener(v -> copyUid(userId));
        ClickAnimationUtil.apply(copyBtn);

        TextView chatBtn = findViewById(R.id.chatBtn);
        chatBtn.setOnClickListener(v -> {
            Intent i = new Intent(UserDetailActivity.this, ChatRoomActivity.class);
            i.putExtra(ChatRoomActivity.EXTRA_UID, userId);
            startActivity(i);
        });
        ClickAnimationUtil.apply(chatBtn);

        uid.setText(userId);

        userRef = FirebaseDatabase.getInstance().getReference("users").child(userId);
        listener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snap) {
                User u = User.parse(userId, snap);
                render(u);
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Toast.makeText(UserDetailActivity.this,
                        R.string.settings_save_failed, Toast.LENGTH_SHORT).show();
            }
        };
    }

    private void render(User u) {
        avatar.setText(u.getInitial());
        name.setText(u.name);
        emailTop.setText(u.email.isEmpty() ? u.uid : u.email);
        email.setText(u.email.isEmpty() ? "—" : u.email);
        device.setText(u.device == null || u.device.trim().isEmpty() ? "—" : u.device);
        app.setText(u.app == null || u.app.trim().isEmpty() ? "—" : u.app);
        appVersion.setText(u.appVersion == null || u.appVersion.trim().isEmpty()
                ? "—" : "v" + u.appVersion);
        appVersionCode.setText(u.appVersionCode > 0 ? String.valueOf(u.appVersionCode) : "—");
        planName.setText(u.planName == null || u.planName.trim().isEmpty()
                ? (u.isPaid() ? getString(R.string.pro_badge) : getString(R.string.free_badge))
                : u.planName);
        planExpiry.setText(u.planExpiry > 0 ? fmt.format(new Date(u.planExpiry)) : "—");
        requestsUsed.setText(String.valueOf(u.requestsUsed));
        photosUsed.setText(String.valueOf(u.photosUsed));
        lastReset.setText(u.lastResetAt > 0 ? fmt.format(new Date(u.lastResetAt)) : getString(R.string.value_never));
        createdAt.setText(fmtTime(u.createdAt));
        lastSeen.setText(fmtTime(u.lastSeen));
        opens.setText(String.valueOf(u.opens));

        boolean live = u.isOnline();
        long now = System.currentTimeMillis();
        if (live) {
            sessionStatus.setText(R.string.status_online);
            sessionStatus.setTextColor(getColor(R.color.codeweave_success));
        } else {
            sessionStatus.setText(R.string.status_offline);
            sessionStatus.setTextColor(getColor(R.color.codeweave_text_secondary));
        }
        sessionStart.setText(fmtTime(u.sessionStart));
        if (live) {
            sessionEnd.setText(getString(R.string.session_running, humanDuration(u.sessionDuration(now))));
            sessionEnd.setTextColor(getColor(R.color.codeweave_success));
        } else {
            sessionEnd.setText(fmtTime(u.sessionEnd));
            sessionEnd.setTextColor(getColor(R.color.codeweave_text_primary));
        }
        long dur = u.sessionDuration(now);
        sessionDuration.setText(dur > 0 ? humanDuration(dur) : getString(R.string.value_never));
        sessions.setText(u.sessionCount > 0 ? String.valueOf(u.sessionCount) : getString(R.string.value_never));
        totalTime.setText(u.totalDurationMs > 0 ? humanDuration(u.totalDurationMs) : getString(R.string.value_never));
        lastActive.setText(fmtTime(u.lastActive));

        if (u.isPaid()) {
            planStatus.setText(R.string.plan_active_active);
            planStatus.setTextColor(getColor(R.color.codeweave_success));
            planBadge.setText(u.planName == null || u.planName.isEmpty()
                    ? getString(R.string.pro_badge) : u.planName);
            planBadge.setTextColor(getColor(R.color.codeweave_gradient_start));
        } else {
            planStatus.setText(R.string.plan_expired_label);
            planStatus.setTextColor(getColor(R.color.codeweave_text_secondary));
            planBadge.setText(getString(R.string.free_badge));
            planBadge.setTextColor(getColor(R.color.codeweave_text_secondary));
        }
    }

    private String fmtTime(long millis) {
        return millis > 0 ? fmt.format(new Date(millis)) : getString(R.string.value_never);
    }

    private String humanDuration(long millis) {
        if (millis <= 0) return "0m";
        long mins = millis / 60000L;
        if (mins < 1) return "<1m";
        if (mins < 60) return mins + "m";
        long hours = mins / 60;
        long rem = mins % 60;
        if (hours < 24) return rem > 0 ? hours + "h " + rem + "m" : hours + "h";
        return (hours / 24) + "d " + (hours % 24) + "h";
    }

    private void copyUid(String userId) {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) {
            cm.setPrimaryClip(ClipData.newPlainText("uid", userId));
            Toast.makeText(this, R.string.uid_copied, Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (userRef != null && listener != null) userRef.addValueEventListener(listener);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (userRef != null && listener != null) userRef.removeEventListener(listener);
    }
}
