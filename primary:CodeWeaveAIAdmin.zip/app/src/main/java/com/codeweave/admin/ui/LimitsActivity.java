package com.codeweave.admin.ui;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.codeweave.admin.R;
import com.codeweave.admin.util.ClickAnimationUtil;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

public class LimitsActivity extends BaseSettingsActivity {

    private EditText freeDailyLimitInput, freeDailyPhotoLimitInput, resetHourInput, priceInput;
    private EditText qrPaytmInput, qrPhonePeInput, qrGpayInput;
    private TextView saveBtn, statusText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_limits);
        setupHeader(R.string.menu_limits);

        freeDailyLimitInput = findViewById(R.id.freeDailyLimitInput);
        freeDailyPhotoLimitInput = findViewById(R.id.freeDailyPhotoLimitInput);
        resetHourInput = findViewById(R.id.resetHourInput);
        priceInput = findViewById(R.id.priceInput);
        qrPaytmInput = findViewById(R.id.qrPaytmInput);
        qrPhonePeInput = findViewById(R.id.qrPhonePeInput);
        qrGpayInput = findViewById(R.id.qrGpayInput);
        saveBtn = findViewById(R.id.saveBtn);
        statusText = findViewById(R.id.statusText);

        configRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snap) {
                loadIntoField(freeDailyLimitInput, snap.child("freeDailyLimit"));
                loadIntoField(freeDailyPhotoLimitInput, snap.child("freeDailyPhotoLimit"));
                loadIntoField(resetHourInput, snap.child("resetHour"));
                loadIntoField(priceInput, snap.child("price"));
                loadIntoField(qrPaytmInput, snap.child("qrPaytm"));
                loadIntoField(qrPhonePeInput, snap.child("qrPhonePe"));
                loadIntoField(qrGpayInput, snap.child("qrGooglePay"));
            }

            @Override
            public void onCancelled(DatabaseError error) {
            }
        });

        saveBtn.setOnClickListener(v -> save());
        ClickAnimationUtil.apply(saveBtn);
    }

    private void save() {
        String limitStr = freeDailyLimitInput.getText().toString().trim();
        String photoStr = freeDailyPhotoLimitInput.getText().toString().trim();
        String hourStr = resetHourInput.getText().toString().trim();
        int limit;
        int photoLimit;
        int hour;
        try {
            limit = Integer.parseInt(limitStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, R.string.invalid_limit, Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            photoLimit = Integer.parseInt(photoStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, R.string.invalid_photo_limit, Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            hour = Integer.parseInt(hourStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, R.string.invalid_hour, Toast.LENGTH_SHORT).show();
            return;
        }
        if (limit <= 0) {
            Toast.makeText(this, R.string.invalid_limit, Toast.LENGTH_SHORT).show();
            return;
        }
        if (photoLimit < 0) {
            Toast.makeText(this, R.string.invalid_photo_limit, Toast.LENGTH_SHORT).show();
            return;
        }
        if (hour < 0 || hour > 23) {
            Toast.makeText(this, R.string.invalid_hour, Toast.LENGTH_SHORT).show();
            return;
        }

        Map<String, Object> data = new HashMap<>();
        data.put("freeDailyLimit", limit);
        data.put("freeDailyPhotoLimit", photoLimit);
        data.put("resetHour", hour);
        data.put("price", priceInput.getText().toString().trim());
        data.put("qrPaytm", qrPaytmInput.getText().toString().trim());
        data.put("qrPhonePe", qrPhonePeInput.getText().toString().trim());
        data.put("qrGooglePay", qrGpayInput.getText().toString().trim());

        saveBtn.setEnabled(false);
        Task<Void> t = configRef.updateChildren(data);
        t.addOnSuccessListener(a -> {
            saveBtn.setEnabled(true);
            statusText.setText(R.string.settings_saved);
            statusText.setVisibility(View.VISIBLE);
        });
        t.addOnFailureListener(e -> {
            saveBtn.setEnabled(true);
            toastSaved(false);
        });
    }
}
