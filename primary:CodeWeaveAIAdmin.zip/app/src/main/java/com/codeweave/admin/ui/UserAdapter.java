package com.codeweave.admin.ui;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.codeweave.admin.R;
import com.codeweave.admin.core.User;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.UserHolder> {

    private static final long NEW_WINDOW = 24L * 3600000L;

    public static final int SORT_ACTIVITY = 0;
    public static final int SORT_NEWEST = 1;
    public static final int SORT_TIME = 2;
    public static final int SORT_NAME = 3;

    private final List<User> all = new ArrayList<>();
    private final List<User> filtered = new ArrayList<>();
    private int sortMode = SORT_ACTIVITY;
    private String query = "";

    private final SimpleDateFormat timeOnly =
            new SimpleDateFormat("hh:mm a", Locale.ENGLISH);
    private final SimpleDateFormat timeWithDate =
            new SimpleDateFormat("dd MMM, hh:mm a", Locale.ENGLISH);
    private final SimpleDateFormat dateOnly =
            new SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH);

    public void setData(List<User> users) {
        all.clear();
        all.addAll(users);
        sortByActivityDesc();
        applyFilter(query);
    }

    public void setFilter(String q) {
        this.query = q == null ? "" : q;
        applyFilter(this.query);
    }

    /** Switches the list order. Default (SORT_ACTIVITY) is live-app usage first. */
    public void setSortMode(int mode) {
        if (sortMode == mode) return;
        sortMode = mode;
        sortByActivityDesc();
        applyFilter(query);
    }

    public int getSortMode() {
        return sortMode;
    }

    private void applyFilter(String q) {
        filtered.clear();
        for (User u : all) {
            if (u.matches(q)) filtered.add(u);
        }
        notifyDataSetChanged();
    }

    private void sortByActivityDesc() {
        Collections.sort(all, new Comparator<User>() {
            @Override
            public int compare(User a, User b) {
                switch (sortMode) {
                    case SORT_NEWEST:
                        return Long.compare(b.createdAt, a.createdAt);
                    case SORT_TIME:
                        return Long.compare(b.totalDurationMs, a.totalDurationMs);
                    case SORT_NAME:
                        int byName = a.name.compareToIgnoreCase(b.name);
                        if (byName != 0) return byName;
                        return Long.compare(b.lastSeen, a.lastSeen);
                    case SORT_ACTIVITY:
                    default:
                        int byActivity = Long.compare(b.lastSeen, a.lastSeen);
                        if (byActivity != 0) return byActivity;
                        return Long.compare(b.createdAt, a.createdAt);
                }
            }
        });
    }

    public int getRawCount() {
        return all.size();
    }

    @NonNull
    @Override
    public UserHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_user, parent, false);
        return new UserHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull UserHolder h, int position) {
        User u = filtered.get(position);
        Context ctx = h.itemView.getContext();

        h.name.setText(u.name);
        h.email.setText(u.email.isEmpty() ? u.uid : u.email);
        h.initial.setText(u.getInitial());
        h.meta.setText(contextString(h.itemView.getContext(), u));

        String session = sessionLine(ctx, u);
        h.sessionLine.setText(session);
        h.sessionLine.setVisibility(session.isEmpty() ? View.GONE : View.VISIBLE);

        String history = historyLine(ctx, u);
        h.historyLine.setText(history);
        h.historyLine.setVisibility(history.isEmpty() ? View.GONE : View.VISIBLE);

        boolean live = u.isOnline();
        h.onlineBadge.setVisibility(live ? View.VISIBLE : View.GONE);

        boolean isNew = u.createdAt > 0 && System.currentTimeMillis() - u.createdAt <= NEW_WINDOW;
        h.newBadge.setVisibility(isNew ? View.VISIBLE : View.GONE);

        String device = u.device;
        if (device != null && !device.trim().isEmpty()) {
            h.deviceBadge.setVisibility(View.VISIBLE);
            h.deviceBadge.setText(device);
        } else {
            h.deviceBadge.setVisibility(View.GONE);
        }

        String ver = (u.appVersion != null && !u.appVersion.trim().isEmpty()) ? "v" + u.appVersion : null;
        if (ver == null && u.appVersionCode > 0) ver = "(" + u.appVersionCode + ")";
        if (ver != null) {
            h.versionBadge.setVisibility(View.VISIBLE);
            h.versionBadge.setText(ver);
        } else {
            h.versionBadge.setVisibility(View.GONE);
        }

        if (u.isPaid()) {
            h.planBadge.setVisibility(View.VISIBLE);
            h.planBadge.setText(ctx.getString(R.string.pro_badge));
            h.planBadge.setTextColor(ctx.getColor(R.color.codeweave_gradient_start));
        } else {
            h.planBadge.setVisibility(View.VISIBLE);
            h.planBadge.setText(ctx.getString(R.string.free_badge));
            h.planBadge.setTextColor(ctx.getColor(R.color.codeweave_text_secondary));
        }

        if (u.isPaid()) {
            h.userUsage.setVisibility(View.VISIBLE);
            String planName = u.planName == null || u.planName.isEmpty() ? ctx.getString(R.string.pro_badge) : u.planName;
            if (u.planExpiry > 0) {
                h.userUsage.setText(ctx.getString(R.string.user_plan_remaining, planName, remainingDuration(u.planExpiry)));
            } else {
                h.userUsage.setText(ctx.getString(R.string.user_plan_active, planName));
            }
        } else if (u.requestsUsed > 0) {
            h.userUsage.setVisibility(View.VISIBLE);
            h.userUsage.setText(ctx.getString(R.string.user_usage, u.requestsUsed));
        } else {
            h.userUsage.setVisibility(View.GONE);
        }

        boolean hasPhoto = u.photo != null && !u.photo.trim().isEmpty();
        h.photo.setVisibility(hasPhoto ? View.VISIBLE : View.INVISIBLE);
        h.initial.setVisibility(hasPhoto ? View.INVISIBLE : View.VISIBLE);
        if (hasPhoto) {
            Glide.with(h.itemView.getContext())
                    .load(u.photo)
                    .apply(RequestOptions.circleCropTransform()
                            .placeholder(R.drawable.bg_avatar)
                            .error(R.drawable.bg_avatar))
                    .into(h.photo);
        }

        h.itemView.setOnClickListener(v -> {
            Intent i = new Intent(ctx, UserDetailActivity.class);
            i.putExtra(UserDetailActivity.EXTRA_UID, u.uid);
            ctx.startActivity(i);
        });
    }

    private String remainingDuration(long expiry) {
        long left = expiry - System.currentTimeMillis();
        if (left <= 0) return "0d";
        long days = left / 86400000L;
        long h = (left % 86400000L) / 3600000L;
        if (days > 0) return h > 0 ? days + "d " + h + "h" : days + "d";
        return Math.max(1, (left + 3599999) / 3600000) + "h";
    }

    private String contextString(Context ctx, User u) {
        String joined = joinedLabel(ctx, u.createdAt);
        String last = u.lastSeen > 0 ? joinedLabel(ctx, u.lastSeen) : "";
        StringBuilder sb = new StringBuilder();
        sb.append(ctx.getString(R.string.user_joined, joined));
        if (!last.isEmpty()) {
            sb.append("   ·   ").append(ctx.getString(R.string.last_seen)).append(": ").append(last);
        }
        if (u.opens > 0) {
            sb.append("   ·   ").append(ctx.getString(R.string.user_opens, u.opens));
        }
        String app = u.app != null ? u.app : "";
        if (u.appVersion != null && !u.appVersion.trim().isEmpty()) {
            app = app + " v" + u.appVersion;
        }
        if (!app.isEmpty()) {
            sb.append("   ·   ").append(app);
        }
        return sb.toString();
    }

    /** "Using now · since 4:12 PM (12m)" or "Used 2:40 PM – 3:05 PM (25m)". */
    private String sessionLine(Context ctx, User u) {
        long now = System.currentTimeMillis();
        boolean live = u.isOnline();
        long start = u.sessionStart;
        long end = live ? now : u.sessionEnd;

        if (start <= 0 && end <= 0) return "";

        if (live && start > 0) {
            return ctx.getString(R.string.session_live,
                    stamp(start), humanDuration(now - start));
        }
        if (start > 0 && end > start) {
            return ctx.getString(R.string.session_done,
                    stamp(start), stamp(end), humanDuration(end - start));
        }
        if (start > 0) {
            return ctx.getString(R.string.session_start_only, stamp(start));
        }
        if (end > 0) {
            return ctx.getString(R.string.last_seen) + ": " + joinedLabel(ctx, end);
        }
        return "";
    }

    /** "12 sessions · total 3h 20m" — hidden until the client reports history. */
    private String historyLine(Context ctx, User u) {
        long sessions = u.sessionCount;
        long total = u.totalDurationMs;
        if (sessions <= 0 && total <= 0) return "";
        if (sessions > 0 && total > 0) {
            return ctx.getString(R.string.user_history, sessions, humanDuration(total));
        }
        if (sessions > 0) {
            return ctx.getString(R.string.user_sessions, sessions);
        }
        return ctx.getString(R.string.user_total_time, humanDuration(total));
    }

    /** Compact time: time-only for today/yesterday, date + time for older. */
    private String stamp(long millis) {
        if (millis <= 0) return "—";
        if (sameDay(millis, System.currentTimeMillis())) {
            return timeOnly.format(new Date(millis));
        }
        return timeWithDate.format(new Date(millis));
    }

    private String humanDuration(long millis) {
        if (millis < 0) return "0m";
        long mins = millis / 60000L;
        if (mins < 1) return "<1m";
        if (mins < 60) return mins + "m";
        long hours = mins / 60;
        long rem = mins % 60;
        if (hours < 24) return rem > 0 ? hours + "h " + rem + "m" : hours + "h";
        long days = hours / 24;
        return days + "d " + (hours % 24) + "h";
    }

    private String joinedLabel(Context ctx, long millis) {
        if (millis <= 0) return "—";
        long now = System.currentTimeMillis();
        long diff = now - millis;
        if (diff < 0) return dateOnly.format(new Date(millis));
        if (diff < 60000L) return ctx.getString(R.string.rel_just_now);
        if (diff < 3600000L) return ctx.getString(R.string.rel_min_ago, (int) (diff / 60000L));
        if (diff < 86400000L && sameDay(millis, now)) {
            return ctx.getString(R.string.rel_today, timeOnly.format(new Date(millis)));
        }
        long yesterday = now - 86400000L;
        if (sameDay(millis, yesterday)) {
            return ctx.getString(R.string.rel_yesterday, timeOnly.format(new Date(millis)));
        }
        long days = diff / 86400000L;
        if (days < 7) return ctx.getString(R.string.rel_day_ago, (int) days);
        return dateOnly.format(new Date(millis));
    }

    private boolean sameDay(long a, long b) {
        Calendar ca = Calendar.getInstance();
        ca.setTimeInMillis(a);
        Calendar cb = Calendar.getInstance();
        cb.setTimeInMillis(b);
        return ca.get(Calendar.YEAR) == cb.get(Calendar.YEAR)
                && ca.get(Calendar.DAY_OF_YEAR) == cb.get(Calendar.DAY_OF_YEAR);
    }

    @Override
    public int getItemCount() {
        return filtered.size();
    }

    static class UserHolder extends RecyclerView.ViewHolder {
        TextView initial, name, email, meta, deviceBadge, versionBadge, planBadge,
                userUsage, newBadge, onlineBadge, sessionLine, historyLine;
        ImageView photo;

        UserHolder(@NonNull View v) {
            super(v);
            initial = v.findViewById(R.id.avatarInitial);
            photo = v.findViewById(R.id.userPhoto);
            name = v.findViewById(R.id.userName);
            email = v.findViewById(R.id.userEmail);
            meta = v.findViewById(R.id.userMeta);
            deviceBadge = v.findViewById(R.id.deviceBadge);
            versionBadge = v.findViewById(R.id.versionBadge);
            planBadge = v.findViewById(R.id.planBadge);
            userUsage = v.findViewById(R.id.userUsage);
            newBadge = v.findViewById(R.id.newBadge);
            onlineBadge = v.findViewById(R.id.onlineBadge);
            sessionLine = v.findViewById(R.id.userSessionLine);
            historyLine = v.findViewById(R.id.userHistoryLine);
        }
    }
}
