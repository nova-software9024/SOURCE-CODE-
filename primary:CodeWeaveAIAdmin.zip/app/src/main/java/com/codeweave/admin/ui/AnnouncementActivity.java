package com.codeweave.admin.ui;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

import com.codeweave.admin.R;
import com.codeweave.admin.core.AdminNotifSync;
import com.codeweave.admin.util.ClickAnimationUtil;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

public class AnnouncementActivity extends BaseSettingsActivity {

    private EditText announcementTitleInput, announcementMessageInput;
    private TextView sendAnnouncementBtn, clearAnnouncementBtn, announcementStatusText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_announcement);
        setupHeader(R.string.menu_announcement);

        announcementTitleInput = findViewById(R.id.announcementTitleInput);
        announcementMessageInput = findViewById(R.id.announcementMessageInput);
        sendAnnouncementBtn = findViewById(R.id.sendAnnouncementBtn);
        clearAnnouncementBtn = findViewById(R.id.clearAnnouncementBtn);
        announcementStatusText = findViewById(R.id.announcementStatusText);

        sendAnnouncementBtn.setOnClickListener(v -> sendAnnouncement());
        ClickAnimationUtil.apply(sendAnnouncementBtn);
        clearAnnouncementBtn.setOnClickListener(v -> clearAnnouncement());
        ClickAnimationUtil.apply(clearAnnouncementBtn);
    }

    private void setAnnouncementStatus(int res, boolean success) {
        announcementStatusText.setText(res);
        announcementStatusText.setTextColor(getColor(success ? R.color.codeweave_success : R.color.error));
        announcementStatusText.setVisibility(android.view.View.VISIBLE);
    }

    private void setAnnouncementStatus(String text, boolean success) {
        announcementStatusText.setText(text);
        announcementStatusText.setTextColor(getColor(success ? R.color.codeweave_success : R.color.error));
        announcementStatusText.setVisibility(android.view.View.VISIBLE);
    }

    private void sendAnnouncement() {
        String title = announcementTitleInput.getText().toString().trim();
        String message = announcementMessageInput.getText().toString().trim();
        if (title.isEmpty() || message.isEmpty()) {
            setAnnouncementStatus(R.string.announcement_required, false);
            return;
        }
        Map<String, Object> ann = new HashMap<>();
        ann.put("title", title);
        ann.put("message", message);
        ann.put("enabled", true);
        ann.put("ts", System.currentTimeMillis());
        configRef.child("announcement").setValue(ann)
                .addOnSuccessListener(a -> AdminNotifSync.writeToAll("announcement", title, message, saved -> {
                    String status = saved > 0
                            ? getString(R.string.announcement_sent) + " (saved to " + saved + " users)"
                            : getString(R.string.announcement_sent);
                    runOnUiThread(() -> setAnnouncementStatus(status, true));
                }))
                .addOnFailureListener(e -> setAnnouncementStatus(R.string.announcement_required, false));
    }

    private void clearAnnouncement() {
        Map<String, Object> ann = new HashMap<>();
        ann.put("enabled", false);
        ann.put("ts", System.currentTimeMillis());
        configRef.child("announcement").updateChildren(ann)
                .addOnSuccessListener(a -> setAnnouncementStatus(R.string.announcement_cleared, true))
                .addOnFailureListener(e -> setAnnouncementStatus(R.string.announcement_required, false));
    }
}
