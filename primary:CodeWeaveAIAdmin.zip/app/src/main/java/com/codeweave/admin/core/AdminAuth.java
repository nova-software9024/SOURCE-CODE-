package com.codeweave.admin.core;

import android.content.Context;
import android.content.SharedPreferences;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

public final class AdminAuth {

    private static final String PREFS = "codeweave_admin_prefs";
    private static final String KEY_UID = "admin_uid";
    private static final String KEY_NAME = "admin_name";
    private static final String KEY_EMAIL = "admin_email";

    public interface AdminCheckCallback {
        void onResult(boolean isAdmin, boolean firstRun, String email);
    }

    private AdminAuth() {}

    public static boolean isSignedIn() {
        try {
            return FirebaseAuth.getInstance().getCurrentUser() != null;
        } catch (Exception e) {
            return false;
        }
    }

    public static String getAdminEmail(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(KEY_EMAIL, "");
    }

    public static void saveSession(Context context, FirebaseUser user) {
        if (user == null) return;
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit()
                .putString(KEY_UID, user.getUid())
                .putString(KEY_NAME, user.getDisplayName() != null ? user.getDisplayName() : "")
                .putString(KEY_EMAIL, user.getEmail() != null ? user.getEmail() : "")
                .apply();
    }

    public static void signOut(Context context) {
        try {
            FirebaseAuth.getInstance().signOut();
        } catch (Exception ignored) {
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit()
                .clear()
                .apply();
    }

    public static void checkAdminAccess(String uid, String email, final AdminCheckCallback callback) {
        if (uid == null) {
            callback.onResult(false, false, email);
            return;
        }
        DatabaseReference adminsRef = FirebaseDatabase.getInstance().getReference("admins");
        adminsRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (snapshot.exists() && snapshot.hasChildren()) {
                    boolean isAdmin = snapshot.child(uid).exists();
                    callback.onResult(isAdmin, false, email);
                } else {
                    // First admin bootstrap: nobody is registered yet, so the
                    // first person to open this panel becomes the super admin.
                    Map<String, Object> data = new HashMap<>();
                    data.put("email", email != null ? email : "");
                    data.put("addedAt", System.currentTimeMillis());
                    adminsRef.child(uid).setValue(data);
                    callback.onResult(true, true, email);
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                callback.onResult(false, false, email);
            }
        });
    }
}
