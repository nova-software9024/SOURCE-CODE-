package com.codeweave.admin.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.codeweave.admin.R;
import com.codeweave.admin.core.AdminAuth;
import com.codeweave.admin.util.ClickAnimationUtil;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;

public class AdminLoginActivity extends AppCompatActivity {

    private static final String TAG = "AdminLogin";

    private GoogleSignInClient googleSignInClient;
    private FrameLayout progressOverlay;
    private boolean navigated = false;

    private final ActivityResultLauncher<Intent> signInLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(result.getData());
                    handleSignInResult(task);
                } else {
                    showProgress(false, null);
                    android.util.Log.d(TAG, "Google sign-in came back cancelled or no data (code="
                            + result.getResultCode() + ")");
                    Toast.makeText(this,
                            "Google sign-in cancelled. Check: 1) phone me Google account hai, 2) app ka signing SHA-1 Firebase console me registered hai.",
                            Toast.LENGTH_LONG).show();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_login);
        getWindow().setStatusBarColor(getColor(R.color.codeweave_bg));

        progressOverlay = findViewById(R.id.progressOverlay);
        View signInBtn = findViewById(R.id.googleSignInBtn);
        ClickAnimationUtil.apply(signInBtn);
        signInBtn.setOnClickListener(v -> startGoogleSignIn());

        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();
        googleSignInClient = GoogleSignIn.getClient(this, gso);

        // Already signed in? Re-verify admin access (silently).
        if (AdminAuth.isSignedIn()) {
            verifyAccess(FirebaseAuth.getInstance().getCurrentUser());
        }
    }

    private void startGoogleSignIn() {
        showProgress(true, getString(R.string.signing_in));
        signInLauncher.launch(googleSignInClient.getSignInIntent());
    }

    private void handleSignInResult(Task<GoogleSignInAccount> completedTask) {
        try {
            GoogleSignInAccount account = completedTask.getResult(ApiException.class);
            firebaseAuthWithGoogle(account.getIdToken());
        } catch (ApiException e) {
            showProgress(false, null);
            android.util.Log.d(TAG, "GoogleSignIn ApiException status=" + e.getStatusCode(), e);
            Toast.makeText(this, getString(R.string.google_sign_in_failed)
                    + " (code " + e.getStatusCode() + ")", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            showProgress(false, null);
            android.util.Log.d(TAG, "GoogleSignIn unexpected error", e);
            Toast.makeText(this, getString(R.string.google_sign_in_failed)
                    + " (" + e.getClass().getSimpleName() + ")", Toast.LENGTH_LONG).show();
        }
    }

    private void firebaseAuthWithGoogle(String idToken) {
        if (idToken == null) {
            showProgress(false, null);
            Toast.makeText(this, R.string.google_sign_in_failed, Toast.LENGTH_LONG).show();
            return;
        }
        AuthCredential credential = GoogleAuthProvider.getCredential(idToken, null);
        FirebaseAuth.getInstance().signInWithCredential(credential)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        verifyAccess(FirebaseAuth.getInstance().getCurrentUser());
                    } else {
                        showProgress(false, null);
                        Toast.makeText(this, R.string.google_sign_in_failed, Toast.LENGTH_LONG).show();
                    }
                });
    }

    private void verifyAccess(FirebaseUser user) {
        if (user == null) {
            showProgress(false, null);
            return;
        }
        showProgress(true, getString(R.string.checking_admin));
        AdminAuth.checkAdminAccess(user.getUid(), user.getEmail(), (isAdmin, firstRun, email) -> {
            runOnUiThread(() -> {
                if (isAdmin) {
                    AdminAuth.saveSession(this, user);
                    if (firstRun) {
                        Toast.makeText(this, R.string.access_granted, Toast.LENGTH_LONG).show();
                    }
                    proceed();
                } else {
                    AdminAuth.signOut(this);
                    showProgress(false, null);
                    Toast.makeText(this, R.string.access_denied_msg, Toast.LENGTH_LONG).show();
                }
            });
        });
    }

    private void proceed() {
        if (navigated) return;
        navigated = true;
        Intent intent = new Intent(this, AdminMainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        finish();
    }

    private void showProgress(boolean show, String msg) {
        if (progressOverlay == null) return;
        progressOverlay.setVisibility(show ? View.VISIBLE : View.GONE);
        if (msg != null && show) {
            android.widget.TextView tv = findViewById(R.id.progressMsg);
            if (tv != null) tv.setText(msg);
        }
    }
}
