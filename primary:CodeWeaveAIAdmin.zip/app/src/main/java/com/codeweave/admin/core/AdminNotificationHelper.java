package com.codeweave.admin.core;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

import androidx.core.app.NotificationCompat;

import com.codeweave.admin.R;
import com.codeweave.admin.ui.AdminMainActivity;

public final class AdminNotificationHelper {
    public static final String CHANNEL_ID = "codeweave_admin_alerts";
    private static final String PREFS = "codeweave_admin_notifs";
    private static final String KEY_IDS = "pending_ids";

    private AdminNotificationHelper() {}

    public static void ensureChannel(Context ctx) {
        try {
            NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;
            NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "Admin Alerts",
                    NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("Payment and user activity alerts");
            ch.enableVibration(true);
            nm.createNotificationChannel(ch);
        } catch (Exception ignored) {
        }
    }

    public static void show(Context ctx, String title, String body, int id) {
        try {
            ensureChannel(ctx);
            NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;

            Intent intent = new Intent(ctx, AdminMainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent pi = PendingIntent.getActivity(ctx, id, intent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

            Notification n = new NotificationCompat.Builder(ctx, CHANNEL_ID)
                    .setSmallIcon(R.drawable.ic_notification)
                    .setContentTitle(title)
                    .setContentText(body)
                    .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
                    .setContentIntent(pi)
                    .setAutoCancel(true)
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                    .build();
            nm.notify(id, n);
        } catch (Exception ignored) {
        }
    }

    public static void cancelAll(Context ctx) {
        try {
            NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;
            nm.cancelAll();
            ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                    .edit().putStringSet(KEY_IDS, new java.util.HashSet<>()).apply();
        } catch (Exception ignored) {
        }
    }
}
