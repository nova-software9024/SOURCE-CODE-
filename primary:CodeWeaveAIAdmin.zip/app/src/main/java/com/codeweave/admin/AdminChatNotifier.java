package com.codeweave.admin;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import androidx.core.app.NotificationCompat;

import com.codeweave.admin.ui.ChatListActivity;
import com.codeweave.admin.ui.ChatRoomActivity;

/**
 * Shared helper that shows chat notifications to the admin with dedup,
 * so the realtime listener and the FCM push never both fire for the same message.
 */
public final class AdminChatNotifier {
    private static final String CHANNEL_ID = "codeweave_admin_chat";
    private static final String PREFS = "codeweave_admin_chat_notified";
    private static final String KEY_PREFIX = "notified_";

    private AdminChatNotifier() {}

    /** Shows a chat notification for the given conversation, only if not already shown for this ts. */
    public static void notifyIfNew(Context ctx, String uid, String name, String text, long ts) {
        if (ctx == null) return;
        SharedPreferences prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String key = KEY_PREFIX + uid + "_" + ts;
        if (prefs.getBoolean(key, false)) return; // already notified this message
        if (ts <= 0) {
            ts = System.currentTimeMillis();
            key = KEY_PREFIX + uid + "_" + ts;
        }
        if (prefs.getBoolean(key, false)) return;

        prefs.edit().putBoolean(key, true).apply();
        show(ctx, uid, name, text);
    }

    /** Clears the dedup for a conversation (called when the admin opens the chat room). */
    public static void markChatOpened(Context ctx, String uid) {
        if (ctx == null || uid == null) return;
        SharedPreferences prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String prefix = KEY_PREFIX + uid + "_";
        SharedPreferences.Editor e = prefs.edit();
        for (String k : prefs.getAll().keySet()) {
            if (k != null && k.startsWith(prefix)) e.remove(k);
        }
        e.apply();
    }

    private static void show(Context ctx, String uid, String name, String text) {
        try {
            NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;

            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "Support Chat",
                        NotificationManager.IMPORTANCE_HIGH);
                ch.enableVibration(true);
                nm.createNotificationChannel(ch);
            }

            Intent intent;
            if (uid != null && !uid.isEmpty()) {
                intent = new Intent(ctx, ChatRoomActivity.class);
                intent.putExtra(ChatRoomActivity.EXTRA_UID, uid);
            } else {
                intent = new Intent(ctx, ChatListActivity.class);
            }
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);

            int id = uid != null ? (uid.hashCode() & 0x7fffffff)
                    : (int) (System.currentTimeMillis() & 0x7fffffff);

            PendingIntent pi = PendingIntent.getActivity(ctx, id, intent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

            Notification n = new NotificationCompat.Builder(ctx, CHANNEL_ID)
                    .setSmallIcon(com.codeweave.admin.R.drawable.ic_notification)
                    .setContentTitle("💬 " + (name == null || name.isEmpty() ? "User" : name))
                    .setContentText(text == null ? "" : text)
                    .setStyle(new NotificationCompat.BigTextStyle().bigText(text == null ? "" : text))
                    .setContentIntent(pi)
                    .setAutoCancel(true)
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                    .build();
            nm.notify(id, n);
        } catch (Exception ignored) {
        }
    }
}
