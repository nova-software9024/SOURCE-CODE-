package com.codeweave.admin.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.codeweave.admin.R;
import com.codeweave.admin.util.ClickAnimationUtil;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ChatListActivity extends AppCompatActivity {

    private final Map<String, Convo> convos = new HashMap<>();
    private final List<Convo> order = new ArrayList<>();
    private ChatAdapter adapter;
    private View emptyView;
    private TextView emptyText;

    private DatabaseReference chatsRef;
    private ChildEventListener chatsListener;

    private static class Convo {
        String uid;
        String userName = "User";
        String lastMessage = "";
        String lastSender = "";
        long lastTs = 0;
        boolean adminUnread = false;

        Convo(String uid) {
            this.uid = uid;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat_list);

        TextView back = findViewById(R.id.backBtn);
        back.setOnClickListener(v -> finish());
        ClickAnimationUtil.apply(back);
        TextView title = findViewById(R.id.pageTitle);
        title.setText(R.string.chats_list_title);

        emptyView = findViewById(R.id.emptyView);
        emptyText = findViewById(R.id.emptyText);

        RecyclerView list = findViewById(R.id.chatsList);
        list.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ChatAdapter();
        list.setAdapter(adapter);

        attachListener();
    }

    private void attachListener() {
        chatsRef = FirebaseDatabase.getInstance().getReference("chats");
        chatsListener = new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot snap, String prev) {
                updateConvo(snap);
            }

            @Override
            public void onChildChanged(DataSnapshot snap, String prev) {
                updateConvo(snap);
            }

            @Override
            public void onChildRemoved(DataSnapshot snap) {
                String uid = snap.getKey();
                if (uid == null) return;
                convos.remove(uid);
                rebuild();
            }

            @Override
            public void onChildMoved(DataSnapshot snap, String prev) {
            }

            @Override
            public void onCancelled(DatabaseError error) {
            }
        };
        chatsRef.addChildEventListener(chatsListener);
    }

    private void updateConvo(DataSnapshot snap) {
        String uid = snap.getKey();
        if (uid == null) return;
        DataSnapshot info = snap.child("info");
        Convo existing = convos.get(uid);
        final Convo c;
        if (existing == null) {
            c = new Convo(uid);
            convos.put(uid, c);
        } else {
            c = existing;
        }
        String last = str(info.child("lastMessage"));
        String sender = str(info.child("lastSender"));
        c.lastMessage = last == null ? "" : last;
        c.lastSender = sender == null ? "" : sender;
        String un = str(info.child("userName"));
        if (un != null && !un.trim().isEmpty()) c.userName = un;
        Long ts = info.child("lastTs").getValue(Long.class);
        c.lastTs = ts != null ? ts : 0L;
        Boolean unread = info.child("adminUnread").getValue(Boolean.class);
        c.adminUnread = unread != null && unread;

        // Look up real user name from users/{uid}
        FirebaseDatabase.getInstance().getReference("users").child(uid).child("name")
                .get().addOnCompleteListener(task -> {
                    try {
                        if (task.isSuccessful() && task.getResult().getValue() != null) {
                            String n = task.getResult().getValue(String.class);
                            if (n != null && !n.trim().isEmpty()) {
                                c.userName = n;
                                adapter.notifyDataSetChanged();
                            }
                        }
                    } catch (Exception ignored) {
                    }
                });

        rebuild();
    }

    private void rebuild() {
        order.clear();
        order.addAll(convos.values());
        Collections.sort(order, (a, b) -> Long.compare(b.lastTs, a.lastTs));
        adapter.notifyDataSetChanged();

        if (order.isEmpty()) {
            emptyText.setText(R.string.chat_no_users);
            emptyView.setVisibility(View.VISIBLE);
        } else {
            emptyView.setVisibility(View.GONE);
        }
    }

    private String str(DataSnapshot snap) {
        Object v = snap.getValue();
        return v != null ? String.valueOf(v) : "";
    }

    @Override
    protected void onDestroy() {
        if (chatsRef != null && chatsListener != null) {
            try {
                chatsRef.removeEventListener(chatsListener);
            } catch (Exception ignored) {
            }
        }
        super.onDestroy();
    }

    private class ChatAdapter extends RecyclerView.Adapter<ChatAdapter.VH> {

        @NonNull
        @Override
        public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_chat_convo, parent, false);
            return new VH(v);
        }

        @Override
        public void onBindViewHolder(@NonNull VH h, int position) {
            Convo c = order.get(position);
            h.avatar.setText(c.userName.isEmpty() ? "?" : c.userName.substring(0, 1).toUpperCase());
            h.name.setText(c.userName);
            String preview = ("admin".equals(c.lastSender) ? "You: " : "") + c.lastMessage;
            h.preview.setText(preview.isEmpty() ? "No messages" : preview);
            h.time.setText(formatTime(c.lastTs));
            h.unreadBadge.setVisibility(c.adminUnread ? View.VISIBLE : View.GONE);

            h.itemView.setOnClickListener(v -> {
                Intent i = new Intent(ChatListActivity.this, ChatRoomActivity.class);
                i.putExtra(ChatRoomActivity.EXTRA_UID, c.uid);
                startActivity(i);
            });
            ClickAnimationUtil.apply(h.itemView);
        }

        @Override
        public int getItemCount() {
            return order.size();
        }

        class VH extends RecyclerView.ViewHolder {
            TextView avatar, name, preview, time, unreadBadge;

            VH(@NonNull View itemView) {
                super(itemView);
                avatar = itemView.findViewById(R.id.convoAvatar);
                name = itemView.findViewById(R.id.convoName);
                preview = itemView.findViewById(R.id.convoPreview);
                time = itemView.findViewById(R.id.convoTime);
                unreadBadge = itemView.findViewById(R.id.convoUnread);
            }
        }
    }

    private String formatTime(long ts) {
        if (ts <= 0) return "";
        java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("dd MMM, hh:mm a", java.util.Locale.US);
        return f.format(new java.util.Date(ts));
    }
}
