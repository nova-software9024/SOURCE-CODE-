package com.codeweave.admin.ui;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.codeweave.admin.R;
import com.codeweave.admin.core.Payment;
import com.codeweave.admin.util.ClickAnimationUtil;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class PaymentAdapter extends RecyclerView.Adapter<PaymentAdapter.PaymentHolder> {

    public interface PaymentActionListener {
        void onApprove(Payment p);
        void onReject(Payment p);
    }

    private final List<Payment> items = new ArrayList<>();
    private final SimpleDateFormat fmt =
            new SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.ENGLISH);
    private PaymentActionListener listener;

    public void setData(List<Payment> payments) {
        items.clear();
        items.addAll(payments);
        Collections.sort(items, (a, b) -> Long.compare(b.createdAt, a.createdAt));
        notifyDataSetChanged();
    }

    public void setListener(PaymentActionListener l) {
        listener = l;
    }

    public int getCount() {
        return items.size();
    }

    @NonNull
    @Override
    public PaymentHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_payment, parent, false);
        return new PaymentHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull PaymentHolder h, int position) {
        Payment p = items.get(position);
        Context ctx = h.itemView.getContext();

        h.userName.setText(p.userName);
        String methodLabel = p.method == null ? "" : p.method;
        String utrLabel = p.utr == null ? "-" : p.utr;
        String amountLabel = p.amount == null || p.amount.isEmpty() ? "-" : p.amount;
        String emailPart = p.userEmail == null || p.userEmail.isEmpty() ? "" : "  ·  " + p.userEmail;
        h.method.setText(ctx.getString(R.string.pay_method_line, methodLabel, emailPart));
        h.utr.setText(ctx.getString(R.string.pay_utr_line, utrLabel));
        h.amount.setText(ctx.getString(R.string.pay_amount_line, amountLabel));
        h.time.setText(fmtTime(p.createdAt));

        h.status.setText(statusLabel(ctx, p.status));
        int color = statusColor(ctx, p.status);
        h.status.setTextColor(color);

        String planName = p.planName == null ? "" : p.planName;
        if (!planName.isEmpty()) {
            h.plan.setVisibility(View.VISIBLE);
            h.plan.setText(ctx.getString(R.string.pay_plan_line, planName, amountLabel));
        } else {
            h.plan.setVisibility(View.GONE);
        }

        boolean pending = p.isPending();
        h.actions.setVisibility(pending ? View.VISIBLE : View.GONE);
        if (pending) {
            h.btnApprove.setOnClickListener(v -> {
                if (listener != null) listener.onApprove(p);
            });
            h.btnReject.setOnClickListener(v -> {
                if (listener != null) listener.onReject(p);
            });
            ClickAnimationUtil.apply(h.btnApprove);
            ClickAnimationUtil.apply(h.btnReject);
        } else {
            h.btnApprove.setOnClickListener(null);
            h.btnReject.setOnClickListener(null);
        }
    }

    private String statusLabel(Context ctx, String status) {
        if ("approved".equals(status)) return ctx.getString(R.string.status_approved);
        if ("rejected".equals(status)) return ctx.getString(R.string.status_rejected);
        return ctx.getString(R.string.status_pending);
    }

    private int statusColor(Context ctx, String status) {
        if ("approved".equals(status)) return ctx.getColor(R.color.codeweave_success);
        if ("rejected".equals(status)) return ctx.getColor(R.color.error);
        return ctx.getColor(R.color.warning);
    }

    private String fmtTime(long millis) {
        if (millis <= 0) return "—";
        return fmt.format(new Date(millis));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class PaymentHolder extends RecyclerView.ViewHolder {
        TextView userName, status, method, utr, amount, time, plan;
        View actions;
        TextView btnApprove, btnReject;

        PaymentHolder(@NonNull View v) {
            super(v);
            userName = v.findViewById(R.id.payUserName);
            status = v.findViewById(R.id.payStatus);
            method = v.findViewById(R.id.payMethod);
            utr = v.findViewById(R.id.payUtr);
            amount = v.findViewById(R.id.payAmount);
            time = v.findViewById(R.id.payTime);
            plan = v.findViewById(R.id.payPlan);
            actions = v.findViewById(R.id.payActions);
            btnApprove = v.findViewById(R.id.btnApprove);
            btnReject = v.findViewById(R.id.btnReject);
        }
    }
}
