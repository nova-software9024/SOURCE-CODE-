package com.codeweave.admin.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.codeweave.admin.R;
import com.codeweave.admin.util.ClickAnimationUtil;

public class SettingsMenuActivity extends BaseSettingsActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings_menu);
        setupHeader(R.string.tab_settings);

        wire(R.id.menuChats, ChatListActivity.class);
        wire(R.id.menuLimits, LimitsActivity.class);
        wire(R.id.menuPlans, PlansActivity.class);
        wire(R.id.menuUpdate, AppUpdateActivity.class);
        wire(R.id.menuPush, PushActivity.class);
        wire(R.id.menuAnnouncement, AnnouncementActivity.class);
        wire(R.id.menuMaintenance, MaintenanceActivity.class);
        wire(R.id.menuAiIdentity, AiIdentityActivity.class);
    }

    private void wire(int id, Class<?> target) {
        View v = findViewById(id);
        if (v == null) return;
        v.setOnClickListener(x -> startActivity(new Intent(this, target)));
        ClickAnimationUtil.apply(v);
    }
}
