package com.codeweave.admin.core;

import android.os.Handler;
import android.os.Looper;
import android.util.Base64;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class PushSender {
    private static final ExecutorService EXEC = Executors.newSingleThreadExecutor();
    private static final String TOKEN_URL = "https://oauth2.googleapis.com/token";
    private static final String SEND_URL = "https://fcm.googleapis.com/v1/projects/%s/messages:send";
    private static final String SCOPE = "https://www.googleapis.com/auth/firebase.messaging";
    public static final String TOPIC_ALL = "codeweave_all";

    public static class ServiceAccount {
        public String clientEmail;
        public String privateKey;
        public String projectId;
    }

    public interface SendCallback {
        void onResult(boolean success, String message);
    }

    private PushSender() {}

    public static ServiceAccount parseServiceAccount(String jsonText) throws Exception {
        JSONObject o = new JSONObject(jsonText);
        ServiceAccount sa = new ServiceAccount();
        sa.clientEmail = o.optString("client_email");
        sa.privateKey = o.optString("private_key");
        sa.projectId = o.optString("project_id");
        return sa;
    }

    public static void sendToAll(final ServiceAccount sa, final String title, final String body, final SendCallback cb) {
        EXEC.execute(() -> {
            try {
                String accessToken = getAccessToken(sa);
                String payload = "{\"message\":{\"topic\":\"" + TOPIC_ALL + "\","
                        + "\"notification\":{\"title\":\"" + escapeJson(title) + "\",\"body\":\"" + escapeJson(body) + "\"},"
                        + "\"android\":{\"priority\":\"high\"}}}";
                postJson(String.format(SEND_URL, sa.projectId), accessToken, payload);
                post(cb, true, "Notification sent to all users.");
            } catch (Exception e) {
                post(cb, false, "Failed: " + e.getMessage());
            }
        });
    }

    public static void sendToToken(final ServiceAccount sa, final String fcmToken, final String title, final String body, final SendCallback cb) {
        EXEC.execute(() -> {
            try {
                String accessToken = getAccessToken(sa);
                String payload = "{\"message\":{\"token\":\"" + fcmToken + "\","
                        + "\"notification\":{\"title\":\"" + escapeJson(title) + "\",\"body\":\"" + escapeJson(body) + "\"},"
                        + "\"android\":{\"priority\":\"high\"}}}";
                postJson(String.format(SEND_URL, sa.projectId), accessToken, payload);
                post(cb, true, "Notification sent.");
            } catch (Exception e) {
                post(cb, false, "Failed: " + e.getMessage());
            }
        });
    }

    private static String getAccessToken(ServiceAccount sa) throws Exception {
        long now = System.currentTimeMillis() / 1000L;
        String headerB64 = b64url("{\"alg\":\"RS256\",\"typ\":\"JWT\"}");
        String claims = "{\"iss\":\"" + sa.clientEmail + "\","
                + "\"scope\":\"" + SCOPE + "\","
                + "\"aud\":\"" + TOKEN_URL + "\","
                + "\"iat\":" + now + ","
                + "\"exp\":" + (now + 3600) + "}";
        String claimsB64 = b64url(claims);
        String signingInput = headerB64 + "." + claimsB64;

        PrivateKey key = loadPrivateKey(sa.privateKey);
        Signature sig = Signature.getInstance("SHA256withRSA");
        sig.initSign(key);
        sig.update(signingInput.getBytes(StandardCharsets.UTF_8));
        String jwt = signingInput + "." + b64url(sig.sign());

        String body = "grant_type=urn:ietf:params:oauth:grant-type:jwt-bearer&assertion="
                + URLEncoder.encode(jwt, "UTF-8");
        HttpURLConnection conn = (HttpURLConnection) new URL(TOKEN_URL).openConnection();
        conn.setRequestMethod("POST");
        conn.setDoOutput(true);
        conn.setConnectTimeout(15000);
        conn.setReadTimeout(15000);
        conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
        try (OutputStream os = conn.getOutputStream()) {
            os.write(body.getBytes(StandardCharsets.UTF_8));
        }
        int code = conn.getResponseCode();
        String resp = read(conn);
        if (code != 200) throw new Exception("Token error " + code + ": " + resp);
        return new JSONObject(resp).getString("access_token");
    }

    private static void postJson(String url, String accessToken, String payload) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
        conn.setRequestMethod("POST");
        conn.setDoOutput(true);
        conn.setConnectTimeout(15000);
        conn.setReadTimeout(15000);
        conn.setRequestProperty("Content-Type", "application/json; UTF-8");
        conn.setRequestProperty("Authorization", "Bearer " + accessToken);
        try (OutputStream os = conn.getOutputStream()) {
            os.write(payload.getBytes(StandardCharsets.UTF_8));
        }
        int code = conn.getResponseCode();
        String resp = read(conn);
        if (code != 200) throw new Exception("Send error " + code + ": " + resp);
    }

    private static String read(HttpURLConnection conn) throws Exception {
        InputStream is = conn.getErrorStream() != null ? conn.getErrorStream() : conn.getInputStream();
        BufferedReader r = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = r.readLine()) != null) sb.append(line);
        return sb.toString();
    }

    private static PrivateKey loadPrivateKey(String pem) throws Exception {
        String cleaned = pem
                .replace("-----BEGIN PRIVATE KEY-----", "")
                .replace("-----END PRIVATE KEY-----", "")
                .replaceAll("\\s", "");
        byte[] der = Base64.decode(cleaned, Base64.DEFAULT);
        PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(der);
        return KeyFactory.getInstance("RSA").generatePrivate(spec);
    }

    private static String b64url(byte[] data) {
        return Base64.encodeToString(data, Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING);
    }

    private static String b64url(String s) {
        return b64url(s.getBytes(StandardCharsets.UTF_8));
    }

    private static String escapeJson(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"")
                .replace("\n", "\\n").replace("\r", "\\r").replace("\t", "\\t");
    }

    private static void post(SendCallback cb, boolean success, String message) {
        new Handler(Looper.getMainLooper()).post(() -> {
            if (cb != null) cb.onResult(success, message);
        });
    }
}
