package com.codeweave.admin.ui;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.codeweave.admin.R;
import com.codeweave.admin.util.ClickAnimationUtil;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

public class AiIdentityActivity extends BaseSettingsActivity {

    private EditText aiNameInput, aiModelInput;
    private TextView saveBtn, statusText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ai_identity);
        setupHeader(R.string.menu_ai_identity);

        aiNameInput = findViewById(R.id.aiNameInput);
        aiModelInput = findViewById(R.id.aiModelInput);
        saveBtn = findViewById(R.id.saveBtn);
        statusText = findViewById(R.id.statusText);

        configRef.child("aiIdentity").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snap) {
                loadIntoField(aiNameInput, snap.child("name"));
                loadIntoField(aiModelInput, snap.child("model"));
            }

            @Override
            public void onCancelled(DatabaseError error) {
            }
        });

        saveBtn.setOnClickListener(v -> save());
        ClickAnimationUtil.apply(saveBtn);
    }

    private void save() {
        String name = aiNameInput.getText().toString().trim();
        String model = aiModelInput.getText().toString().trim();
        if (name.isEmpty()) {
            name = "CodeWeave AI";
            aiNameInput.setText(name);
        }

        Map<String, Object> identity = new HashMap<>();
        identity.put("name", name);
        identity.put("model", model);

        saveBtn.setEnabled(false);
        configRef.child("aiIdentity").updateChildren(identity)
                .addOnSuccessListener(a -> {
                    saveBtn.setEnabled(true);
                    statusText.setText(R.string.settings_saved);
                    statusText.setVisibility(View.VISIBLE);
                })
                .addOnFailureListener(e -> {
                    saveBtn.setEnabled(true);
                    toastSaved(false);
                });
    }
}