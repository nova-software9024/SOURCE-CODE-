package com.codeweave.admin.ui;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.codeweave.admin.R;
import com.codeweave.admin.util.ClickAnimationUtil;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public abstract class BaseSettingsActivity extends AppCompatActivity {

    protected DatabaseReference configRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        configRef = FirebaseDatabase.getInstance().getReference("adminConfig");
    }

    protected void setupHeader(int titleRes) {
        TextView back = findViewById(R.id.backBtn);
        TextView title = findViewById(R.id.pageTitle);
        if (title != null) title.setText(titleRes);
        if (back != null) {
            back.setOnClickListener(v -> finish());
            ClickAnimationUtil.apply(back);
        }
        TextView pageText = findViewById(R.id.pageTitleText);
        if (pageText != null) pageText.setText(titleRes);
    }

    protected void loadIntoField(EditText field, DataSnapshot snap) {
        Object v = snap.getValue();
        if (v != null) field.setText(String.valueOf(v));
    }

    protected void toastSaved(boolean success) {
        Toast.makeText(this,
                success ? R.string.settings_saved : R.string.settings_save_failed,
                Toast.LENGTH_SHORT).show();
    }

    protected void showConfirm(int titleRes, String message, Runnable onYes) {
        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle(titleRes)
                .setMessage(message)
                .setNegativeButton(R.string.cancel, null)
                .setPositiveButton(R.string.ok, (d, w) -> onYes.run())
                .show();
    }

    protected int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
