package com.codeweave.admin;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;

import androidx.core.app.NotificationCompat;

import com.codeweave.admin.ui.AdminMainActivity;
import com.codeweave.admin.ui.ChatListActivity;
import com.codeweave.admin.ui.ChatRoomActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import java.util.Map;

public class CodeWeaveAdminMessagingService extends FirebaseMessagingService {

    private static final String CHANNEL_ID = "codeweave_admin_chat";
    private static final String TAG = "AdminFcm";

    @Override
    public void onNewToken(String token) {
        saveToken(token);
    }

    @Override
    public void onMessageReceived(RemoteMessage message) {
        Map<String, String> data = message.getData();

        // Chat push: from a user. data: chat=true, uid=<userUid>, name, text, ts
        if (data != null && "1".equals(data.get("chat"))) {
            String uid = data.get("uid");
            String name = data.get("name");
            String text = data.get("text");
            String tsStr = data.get("ts");
            long ts = 0;
            try {
                ts = Long.parseLong(String.valueOf(tsStr));
            } catch (Exception ignored) {
            }
            if (name == null) name = "User";
            if (text == null) text = "";

            saveToken(null);
            AdminChatNotifier.notifyIfNew(this, uid, name, text, ts);
            return;
        }

        // Generic push
        String title = message.getNotification() != null ? message.getNotification().getTitle() : "CodeWeave Admin";
        String body = message.getNotification() != null ? message.getNotification().getBody() : "";
        if (data != null && (title == null || title.isEmpty())) title = data.get("title");
        if (data != null && (body == null || body.isEmpty())) body = data.get("body");

        Intent intent = new Intent(this, AdminMainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        showNotification(intent, title, body, (int) (System.currentTimeMillis() & 0x7fffffff));
    }

    private void showNotification(Intent intent, String title, String body, int id) {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm == null) return;

            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "Support Chat",
                        NotificationManager.IMPORTANCE_HIGH);
                ch.enableVibration(true);
                nm.createNotificationChannel(ch);
            }

            PendingIntent pi = PendingIntent.getActivity(this, id, intent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

            Notification n = new NotificationCompat.Builder(this, CHANNEL_ID)
                    .setSmallIcon(R.drawable.ic_notification)
                    .setContentTitle(title)
                    .setContentText(body)
                    .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
                    .setContentIntent(pi)
                    .setAutoCancel(true)
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                    .build();
            nm.notify(id, n);
        } catch (Exception ignored) {
        }
    }

    private void saveToken(String token) {
        try {
            if (token == null) {
                FirebaseMessaging.getInstance().getToken().addOnCompleteListener(task -> {
                    if (task.isSuccessful() && task.getResult() != null) {
                        storeToken(task.getResult());
                    }
                });
            } else {
                storeToken(token);
            }
        } catch (Exception ignored) {
        }
    }

    private void storeToken(String token) {
        try {
            String uid = FirebaseAuth.getInstance().getCurrentUser() != null
                    ? FirebaseAuth.getInstance().getCurrentUser().getUid() : null;
            if (uid == null || token == null || token.isEmpty()) return;
            DatabaseReference ref = FirebaseDatabase.getInstance().getReference("admins").child(uid);
            ref.child("fcmToken").setValue(token);
        } catch (Exception ignored) {
        }
    }
}
