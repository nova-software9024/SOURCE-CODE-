package com.codeweave.admin.core;

import com.google.firebase.database.DataSnapshot;

public class Payment {

    public String id;
    public String userId;
    public String userName;
    public String userEmail;
    public String method;
    public String utr;
    public String amount;
    public String planId;
    public String planName;
    public int planDays;
    public String status;
    public long createdAt;

    public static Payment parse(String id, DataSnapshot snap) {
        Payment p = new Payment();
        p.id = id;
        p.userId = snap.child("userId").getValue(String.class);
        p.userName = snap.child("userName").getValue(String.class);
        p.userEmail = snap.child("userEmail").getValue(String.class);
        p.method = snap.child("method").getValue(String.class);
        p.utr = snap.child("utr").getValue(String.class);
        p.amount = snap.child("amount").getValue(String.class);
        p.planId = snap.child("planId").getValue(String.class);
        p.planName = snap.child("planName").getValue(String.class);
        Integer pd = snap.child("planDays").getValue(Integer.class);
        p.planDays = pd != null ? pd : 0;
        p.status = snap.child("status").getValue(String.class);
        Long ca = snap.child("createdAt").getValue(Long.class);
        p.createdAt = ca != null ? ca : 0L;
        if (p.userName == null || p.userName.trim().isEmpty()) p.userName = "User";
        if (p.userEmail == null) p.userEmail = "";
        if (p.method == null) p.method = "";
        if (p.utr == null) p.utr = "";
        if (p.amount == null) p.amount = "";
        if (p.planId == null) p.planId = "";
        if (p.planName == null) p.planName = "";
        if (p.status == null) p.status = "pending";
        return p;
    }

    public boolean isPending() {
        return "pending".equals(status);
    }
}
