package com.codeweave.admin.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

import androidx.core.content.ContextCompat;

import com.codeweave.admin.R;

import java.util.ArrayList;
import java.util.List;

public class ChartView extends View {

    public static class DataPoint {
        public final String label;
        public final float value;
        public DataPoint(String label, float value) {
            this.label = label;
            this.value = value;
        }
    }

    private final List<DataPoint> points = new ArrayList<>();
    private final Paint barPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint gridPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint labelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private int barColor;

    public ChartView(Context context) {
        super(context);
        init(context);
    }

    public ChartView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public ChartView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    private void init(Context context) {
        barColor = ContextCompat.getColor(context, R.color.codeweave_gradient_start);
        barPaint.setColor(barColor);
        barPaint.setStyle(Paint.Style.FILL);

        gridPaint.setColor(ContextCompat.getColor(context, R.color.codeweave_text_secondary));
        gridPaint.setStrokeWidth(2f);

        textPaint.setColor(ContextCompat.getColor(context, R.color.codeweave_text_primary));
        textPaint.setTextSize(sp(10));
        textPaint.setTextAlign(Paint.Align.CENTER);

        labelPaint.setColor(ContextCompat.getColor(context, R.color.codeweave_text_secondary));
        labelPaint.setTextSize(sp(9));
        labelPaint.setTextAlign(Paint.Align.CENTER);
    }

    public void setData(List<DataPoint> data) {
        points.clear();
        if (data != null) points.addAll(data);
        invalidate();
    }

    public void setBarColor(int color) {
        barColor = color;
        barPaint.setColor(color);
        invalidate();
    }

    private float sp(int v) {
        return v * getResources().getDisplayMetrics().scaledDensity;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        float w = getWidth() - getPaddingLeft() - getPaddingRight();
        float h = getHeight() - getPaddingTop() - getPaddingBottom();
        if (w <= 0 || h <= 0 || points.isEmpty()) {
            drawPlaceholder(canvas);
            return;
        }

        float left = getPaddingLeft() + sp(6);
        float right = getPaddingRight() + sp(6);
        float top = getPaddingTop() + sp(4);
        float bottom = getHeight() - getPaddingBottom() - sp(4);

        float chartW = w - sp(12);
        float chartH = h - sp(18);

        float max = 0f;
        for (DataPoint p : points) {
            if (p.value > 0 && p.value > max) max = p.value;
        }
        if (max <= 0f) {
            drawPlaceholder(canvas);
            return;
        }
        float topPadding = sp(8);
        float usableH = chartH - topPadding;

        int n = points.size();
        float slot = chartW / n;
        float barWidth = Math.min(slot * 0.5f, sp(22));

        float x = left;
        for (int i = 0; i < n; i++) {
            DataPoint p = points.get(i);
            float barH = max > 0 ? (p.value / max) * usableH : 0f;
            if (barH < 2f && p.value > 0) barH = 2f;
            float cx = x + slot / 2f;
            float barTop = top + topPadding + (usableH - barH);
            RectF bar = new RectF(cx - barWidth / 2f, barTop, cx + barWidth / 2f, top + topPadding + usableH);
            canvas.drawRoundRect(bar, sp(2), sp(2), barPaint);

            if (p.value > 0f) {
                canvas.drawText(formatValue(p.value), cx, barTop - sp(2), textPaint);
            }
            canvas.drawText(p.label, cx, top + topPadding + usableH + sp(6), labelPaint);

            x += slot;
        }
    }

    private String formatValue(float v) {
        if (v >= 1000000L) {
            return String.format("%.1fM", v / 1000000f);
        } else if (v >= 1000L) {
            return String.format("%.1fk", v / 1000f);
        }
        return String.valueOf(Math.round(v));
    }

    private void drawPlaceholder(Canvas canvas) {
        labelPaint.setTextAlign(Paint.Align.CENTER);
        labelPaint.setColor(ContextCompat.getColor(getContext(), R.color.codeweave_text_secondary));
        canvas.drawText("—", getWidth() / 2f, getHeight() / 2f, labelPaint);
    }
}
