package com.codeweave.admin.util;

import android.view.MotionEvent;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;

public class ClickAnimationUtil {

    private static final long PRESS_DURATION = 85;
    private static final long RELEASE_DURATION = 350;
    private static final float PRESS_SCALE = 0.94f;
    private static final float PRESS_ALPHA = 0.82f;

    public static void apply(View view) {
        view.setOnTouchListener(new View.OnTouchListener() {
            private boolean isPressed = false;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        isPressed = true;
                        v.animate().cancel();
                        v.animate()
                            .scaleX(PRESS_SCALE)
                            .scaleY(PRESS_SCALE)
                            .alpha(PRESS_ALPHA)
                            .setDuration(PRESS_DURATION)
                            .setInterpolator(new DecelerateInterpolator(2.5f))
                            .setListener(null)
                            .start();
                        break;

                    case MotionEvent.ACTION_UP:
                        if (isPressed) {
                            isPressed = false;
                            v.animate().cancel();
                            v.animate()
                                .scaleX(1.0f)
                                .scaleY(1.0f)
                                .alpha(1.0f)
                                .setDuration(RELEASE_DURATION)
                                .setInterpolator(new OvershootInterpolator(1.8f))
                                .setListener(null)
                                .start();
                        }
                        break;

                    case MotionEvent.ACTION_CANCEL:
                        if (isPressed) {
                            isPressed = false;
                            v.animate().cancel();
                            v.animate()
                                .scaleX(1.0f)
                                .scaleY(1.0f)
                                .alpha(1.0f)
                                .setDuration(RELEASE_DURATION)
                                .setInterpolator(new DecelerateInterpolator(2f))
                                .setListener(null)
                                .start();
                        }
                        break;
                }
                return false;
            }
        });
    }

    public static void applyToAll(View... views) {
        for (View v : views) {
            if (v != null) apply(v);
        }
    }
}
