package com.codeweave.admin.ui;

import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;

import com.codeweave.admin.R;
import com.codeweave.admin.util.ClickAnimationUtil;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PlansActivity extends BaseSettingsActivity {

    private EditText planNameInput, planDaysInput, planPriceInput, planQrInput;
    private View addPlanBtn, saveBtn;
    private LinearLayout plansListContainer;
    private final List<PlanEntry> localPlans = new ArrayList<>();

    private static class PlanEntry {
        String id;
        String name;
        int days;
        String price;
        String qrUrl;

        PlanEntry(String id, String name, int days, String price, String qrUrl) {
            this.id = id;
            this.name = name;
            this.days = days;
            this.price = price;
            this.qrUrl = qrUrl != null ? qrUrl : "";
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_plans);
        setupHeader(R.string.menu_plans);

        planNameInput = findViewById(R.id.planNameInput);
        planDaysInput = findViewById(R.id.planDaysInput);
        planPriceInput = findViewById(R.id.planPriceInput);
        planQrInput = findViewById(R.id.planQrInput);
        addPlanBtn = findViewById(R.id.addPlanBtn);
        saveBtn = findViewById(R.id.saveBtn);
        plansListContainer = findViewById(R.id.plansListContainer);

        configRef.child("plans").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot plansSnap) {
                localPlans.clear();
                for (DataSnapshot planChild : plansSnap.getChildren()) {
                    String name = planChild.child("name").getValue(String.class);
                    Integer days = planChild.child("days").getValue(Integer.class);
                    String price = planChild.child("price").getValue(String.class);
                    String qrUrl = planChild.child("qrUrl").getValue(String.class);
                    if (name != null) {
                        localPlans.add(new PlanEntry(planChild.getKey(), name,
                                days != null ? days : 0,
                                price != null ? price : "",
                                qrUrl != null ? qrUrl : ""));
                    }
                }
                renderPlans();
            }

            @Override
            public void onCancelled(DatabaseError error) {
            }
        });

        addPlanBtn.setOnClickListener(v -> addPlan());
        ClickAnimationUtil.apply(addPlanBtn);
        saveBtn.setOnClickListener(v -> save());
        ClickAnimationUtil.apply(saveBtn);
    }

    private void addPlan() {
        String name = planNameInput.getText().toString().trim();
        String daysStr = planDaysInput.getText().toString().trim();
        String price = planPriceInput.getText().toString().trim();
        if (name.isEmpty()) {
            Toast.makeText(this, R.string.plan_name_required, Toast.LENGTH_SHORT).show();
            return;
        }
        int days;
        try {
            days = Integer.parseInt(daysStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, R.string.plan_days_required, Toast.LENGTH_SHORT).show();
            return;
        }
        if (days <= 0) {
            Toast.makeText(this, R.string.plan_days_required, Toast.LENGTH_SHORT).show();
            return;
        }
        if (price.isEmpty()) {
            Toast.makeText(this, R.string.plan_price_required, Toast.LENGTH_SHORT).show();
            return;
        }
        localPlans.add(new PlanEntry("plan_" + System.currentTimeMillis(), name, days, price,
                planQrInput.getText().toString().trim()));
        planNameInput.setText("");
        planDaysInput.setText("");
        planPriceInput.setText("");
        planQrInput.setText("");
        renderPlans();
    }

    private void renderPlans() {
        plansListContainer.removeAllViews();
        for (final PlanEntry entry : localPlans) {
            plansListContainer.addView(renderPlanRow(entry));
        }
    }

    private View renderPlanRow(final PlanEntry entry) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(2), dp(6), dp(2), dp(6));

        LinearLayout textWrap = new LinearLayout(this);
        textWrap.setOrientation(LinearLayout.VERTICAL);
        textWrap.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        TextView name = new TextView(this);
        name.setText(entry.name + "  ·  " + entry.days + " days  ·  ₹" + entry.price
                + (entry.qrUrl.isEmpty() ? "" : "\nQR: " + shorten(entry.qrUrl)));
        name.setTextColor(getColor(R.color.codeweave_text_primary));
        name.setTextSize(14f);
        name.setTextIsSelectable(false);
        name.setOnClickListener(v -> showEditDialog(entry));
        textWrap.addView(name);

        TextView edit = new TextView(this);
        edit.setText(R.string.edit_plan);
        edit.setTextColor(getColor(R.color.codeweave_gradient_start));
        edit.setTextSize(13f);
        edit.setPadding(dp(8), dp(6), dp(2), dp(6));
        edit.setOnClickListener(v -> showEditDialog(entry));
        ClickAnimationUtil.apply(edit);

        TextView editQr = new TextView(this);
        editQr.setText(R.string.edit_qr);
        editQr.setTextColor(getColor(R.color.codeweave_gradient_start));
        editQr.setTextSize(13f);
        editQr.setPadding(dp(8), dp(6), dp(2), dp(6));
        editQr.setOnClickListener(v -> showQrEditDialog(entry));
        ClickAnimationUtil.apply(editQr);

        TextView del = new TextView(this);
        del.setText(R.string.delete_plan);
        del.setTextColor(getColor(R.color.error));
        del.setTextSize(13f);
        del.setPadding(dp(8), dp(6), dp(2), dp(6));
        del.setOnClickListener(v -> showConfirm(R.string.delete_plan_title,
                getString(R.string.delete_plan_msg, entry.name), () -> {
                    localPlans.remove(entry);
                    renderPlans();
                }));
        ClickAnimationUtil.apply(del);

        row.addView(textWrap);
        row.addView(edit);
        row.addView(editQr);
        row.addView(del);
        return row;
    }

    private String shorten(String url) {
        return url.length() > 40 ? url.substring(0, 40) + "…" : url;
    }

    private void showQrEditDialog(final PlanEntry entry) {
        final EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setText(entry.qrUrl);
        input.setHint(R.string.plan_qr_hint);
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.edit_qr_title) + " — " + entry.name)
                .setView(input)
                .setNegativeButton(R.string.cancel, null)
                .setPositiveButton(R.string.ok, (d, w) -> {
                    entry.qrUrl = input.getText().toString().trim();
                    renderPlans();
                    Toast.makeText(this, R.string.qr_updated_tap_save, Toast.LENGTH_SHORT).show();
                })
                .show();
    }

    private void showEditDialog(final PlanEntry entry) {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setPadding(dp(24), dp(12), dp(24), dp(4));

        final EditText nameInput = new EditText(this);
        nameInput.setSingleLine(true);
        nameInput.setText(entry.name);
        nameInput.setHint(R.string.plan_name_hint);

        final EditText daysInput = new EditText(this);
        daysInput.setSingleLine(true);
        daysInput.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        daysInput.setText(String.valueOf(entry.days));
        daysInput.setHint(R.string.plan_days_hint);

        final EditText priceInput = new EditText(this);
        priceInput.setSingleLine(true);
        priceInput.setText(entry.price);
        priceInput.setHint(R.string.plan_price_hint);

        final EditText qrInput = new EditText(this);
        qrInput.setSingleLine(true);
        qrInput.setText(entry.qrUrl);
        qrInput.setHint(R.string.plan_qr_hint);

        wrap.addView(fieldLabel(R.string.plan_name));
        wrap.addView(nameInput);
        wrap.addView(fieldLabel(R.string.plan_days));
        wrap.addView(daysInput);
        wrap.addView(fieldLabel(R.string.plan_price));
        wrap.addView(priceInput);
        wrap.addView(fieldLabel(R.string.plan_qr));
        wrap.addView(qrInput);

        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.edit_plan_title) + " — " + entry.name)
                .setView(wrap)
                .setNegativeButton(R.string.cancel, null)
                .setPositiveButton(R.string.ok, (d, w) -> {
                    String newName = nameInput.getText().toString().trim();
                    String daysStr = daysInput.getText().toString().trim();
                    String newPrice = priceInput.getText().toString().trim();
                    if (newName.isEmpty()) {
                        Toast.makeText(this, R.string.plan_name_required, Toast.LENGTH_SHORT).show();
                        return;
                    }
                    int newDays = entry.days;
                    try {
                        newDays = Integer.parseInt(daysStr);
                    } catch (NumberFormatException e) {
                        Toast.makeText(this, R.string.plan_days_required, Toast.LENGTH_SHORT).show();
                        return;
                    }
                    entry.name = newName;
                    entry.days = newDays;
                    entry.price = newPrice;
                    entry.qrUrl = qrInput.getText().toString().trim();
                    renderPlans();
                    Toast.makeText(this, R.string.plan_edit_saved, Toast.LENGTH_SHORT).show();
                })
                .show();
    }

    private TextView fieldLabel(int resId) {
        TextView lbl = new TextView(this);
        lbl.setText(resId);
        lbl.setTextColor(getColor(R.color.codeweave_text_secondary));
        lbl.setTextSize(12f);
        lbl.setPadding(0, dp(10), 0, dp(2));
        return lbl;
    }

    private void save() {
        Map<String, Object> plansMap = new HashMap<>();
        for (PlanEntry entry : localPlans) {
            Map<String, Object> pv = new HashMap<>();
            pv.put("name", entry.name);
            pv.put("days", entry.days);
            pv.put("price", entry.price);
            pv.put("qrUrl", entry.qrUrl);
            plansMap.put(entry.id, pv);
        }
        saveBtn.setEnabled(false);
        configRef.child("plans").setValue(plansMap)
                .addOnSuccessListener(a -> {
                    saveBtn.setEnabled(true);
                    Toast.makeText(this, R.string.settings_saved, Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e -> {
                    saveBtn.setEnabled(true);
                    toastSaved(false);
                });
    }
}
