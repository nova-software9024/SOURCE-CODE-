package com.codeweave.admin;

import android.app.Application;
import android.content.SharedPreferences;

import com.codeweave.admin.core.AdminNotificationHelper;
import com.codeweave.admin.core.Payment;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class AdminApp extends Application {

    private static AdminApp instance;
    private static final String PREFS = "codeweave_admin_notifs";
    private static final String KEY_LAST_SEEN = "last_seen_payment";

    public static AdminApp getInstance() {
        return instance;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        try {
            FirebaseApp.initializeApp(this);
            AdminNotificationHelper.ensureChannel(this);
            watchPayments();
            watchChats();
        } catch (Exception ignored) {
        }
    }

    /** Shows an admin notification the moment a user sends a new chat message (while app process is alive). */
    private void watchChats() {
        try {
            DatabaseReference chatsRef = FirebaseDatabase.getInstance().getReference("chats");
            chatsRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot snapshot) {
                    for (DataSnapshot userChat : snapshot.getChildren()) {
                        String uid = userChat.getKey();
                        if (uid == null) continue;
                        DataSnapshot info = userChat.child("info");
                        boolean adminUnread = Boolean.TRUE.equals(info.child("adminUnread").getValue(Boolean.class));
                        if (!adminUnread) continue;
                        String lastSender = info.child("lastSender").getValue(String.class);
                        if (!"user".equals(lastSender)) continue;
                        String text = info.child("lastMessage").getValue(String.class);
                        String name = info.child("userName").getValue(String.class);
                        Long ts = info.child("lastTs").getValue(Long.class);
                        if (text == null || text.isEmpty()) continue;
                        AdminChatNotifier.notifyIfNew(getApplicationContext(), uid,
                                name == null ? "User" : name, text, ts != null ? ts : 0L);
                    }
                }

                @Override
                public void onCancelled(DatabaseError error) {
                }
            });
        } catch (Exception ignored) {
        }
    }

    /** Shows an admin notification the moment a user submits a new pending payment. */
    private void watchPayments() {
        try {
            final SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
            long lastSeen = prefs.getLong(KEY_LAST_SEEN, 0L);
            final boolean firstRun = lastSeen <= 0;

            DatabaseReference paymentsRef = FirebaseDatabase.getInstance().getReference("payments");
            paymentsRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot snapshot) {
                    long maxCreated = prefs.getLong(KEY_LAST_SEEN, 0L);
                    for (DataSnapshot child : snapshot.getChildren()) {
                        if (!"pending".equals(child.child("status").getValue(String.class))) continue;
                        Long created = child.child("createdAt").getValue(Long.class);
                        if (created == null || created <= 0) continue;
                        if (created > maxCreated) maxCreated = created;
                        if (firstRun || created <= lastSeen) continue;
                        Payment p = Payment.parse(child.getKey(), child);
                        String title = getString(com.codeweave.admin.R.string.admin_notif_payment_title);
                        String user = p.userName != null && !p.userName.isEmpty() ? p.userName : "User";
                        String plan = p.planName != null && !p.planName.isEmpty() ? p.planName : "a plan";
                        String amount = p.amount != null && !p.amount.isEmpty() ? "₹" + p.amount : "";
                        String body = amount.isEmpty()
                                ? getString(com.codeweave.admin.R.string.admin_notif_payment_body_no_amount, user, plan)
                                : getString(com.codeweave.admin.R.string.admin_notif_payment_body, user, plan, amount);
                        AdminNotificationHelper.show(getApplicationContext(), title, body, child.getKey().hashCode() & 0x7fffffff);
                    }
                    if (maxCreated > 0) {
                        prefs.edit().putLong(KEY_LAST_SEEN, maxCreated).apply();
                    }
                }

                @Override
                public void onCancelled(DatabaseError error) {
                }
            });
        } catch (Exception ignored) {
        }
    }
}
